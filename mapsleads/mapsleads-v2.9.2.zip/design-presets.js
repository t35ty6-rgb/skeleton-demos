// MapsLeads · デザイン の 注文 プリセット (v2.7.0 · プルダウン 式)
// popup / mockup の 両方 が 読み込む。 選ぶ だけ で
//  (1) AI へ の 指示文 (brief)
//  (2) preview の 見た目 (style / 色 / 文字 サイズ / 写真 枚数)
// が 決まる。 hint = 選ぶ と どう なる か の 説明、 ex = 出来上がり の 例。
const ML_DESIGN_GROUPS = [
  {
    key: 'vibe',
    label: 'テイスト（全体 の 空気）',
    note: '見た目 と 文章 の 方向 が まとめて 変わります',
    options: [
      { v: 'auto',    l: 'おまかせ（業種 に 合わせる）', hint: '業種 から 自動 で 選びます。' },
      { v: 'pop',     l: 'ポップで明るい', style: 'H',
        brief: '全体を明るくポップに。丸みのある形と元気のある見出しで、堅苦しさを出さない。',
        hint: '太い見出し・元気な配色。若い客層や、気軽さを売りにする店向け。' },
      { v: 'lux',     l: '上品・高級感', style: 'B',
        brief: '余白を広く取り、上品で高級感のある落ち着いたトーンにする。装飾は最小限。',
        hint: '黒×金の落ち着いた画面。単価の高いサロンや隠れ家系の店向け。' },
      { v: 'natural', l: 'ナチュラル・やさしい', style: 'D',
        brief: 'やわらかく親しみのあるトーン。温かみのある言葉づかいで、押し付けがましくしない。',
        hint: '生成り色のやさしい画面。カフェ・雑貨・子ども連れの多い店向け。' },
      { v: 'cute',    l: 'かわいい・やわらか', style: 'G',
        brief: 'やさしい色と丸い形で、かわいらしい印象にする。言葉も柔らかくする。',
        hint: '淡いピンク基調。ネイル・まつげ・エステ向け。' },
      { v: 'wa',      l: '和・落ち着き', style: 'E',
        brief: '和の落ち着いたトーン。余白を大事にし、言葉は簡潔にする。',
        hint: '和の設え。日本料理・着物・老舗向け。' },
      { v: 'sharp',   l: '都会的・シャープ', style: 'F',
        brief: '都会的でシャープなトーン。無駄を削り、短く言い切る見出しにする。',
        hint: '黒基調で文字が主役。デザイン性で見せたい店向け。' },
      { v: 'clean',   l: '清潔・信頼感', style: 'C',
        brief: '清潔で信頼感のあるトーン。誇張を避け、事実を落ち着いて伝える。',
        hint: '白基調でまっすぐ。歯科・整体・士業向け。' }
    ]
  },
  {
    key: 'catch',
    label: 'キャッチコピー の 作り方',
    note: '一番 大きい 見出し の 書き方 が 変わります',
    options: [
      { v: 'auto',   l: 'おまかせ', hint: 'AI が 店 に 合う 形 を 選びます。' },
      { v: 'nayami', l: 'お客さんの悩みから入る',
        brief: 'キャッチコピーは客の悩みや不便から書き出す。解決を約束する前に、まず相手の困りごとを言い当てる。',
        hint: '読んだ人が「それ自分だ」と思う入り方。', ex: '寝ぐせが、毎朝の敵だった。' },
      { v: 'toikake', l: '問いかける',
        brief: 'キャッチコピーは読み手への問いかけにする。「〜ませんか」「〜ですか」で終える形。',
        hint: '押しつけずに引き込む。初回来店を増やしたい時に。', ex: '朝の支度、もっと短くなりませんか。' },
      { v: 'yakusoku', l: '店からの約束にする',
        brief: 'キャッチコピーは店からの約束の形にする。「〜します」「〜まで」など、client に対する宣言。',
        hint: '言い切って信頼を取る。技術に自信がある店向け。', ex: '三か月先まで、まとまる髪に。' },
      { v: 'jokei',  l: '情景を描く',
        brief: 'キャッチコピーは店や客の情景を一枚の絵として描く。説明せず、場面だけを見せる。',
        hint: '空気感で売る。雰囲気が強みの店向け。', ex: '窓際の席で、鋏の音だけ。' },
      { v: 'mijikaku', l: '短く、強く',
        brief: 'キャッチコピーは8〜12文字の極端に短い一撃にする。説明を一切足さない。',
        hint: '一瞬で刺す。看板やチラシにも流用しやすい。', ex: '切る前に、聴く。' },
      { v: 'tenmei', l: '店名を主役にする',
        brief: 'キャッチコピーに店名を入れ、店名そのものを覚えてもらう形にする。',
        hint: '名前を憶えてほしい新店・リブランド時に。', ex: '一花で、髪を整えるということ。' }
    ]
  },
  {
    key: 'tone',
    label: '言葉づかい',
    note: '本文 の 語り口 が 変わります',
    options: [
      { v: 'auto',    l: 'おまかせ', hint: 'テイスト に 合わせて AI が 決めます。' },
      { v: 'teinei',  l: 'ていねい（です・ます）',
        brief: '文章全体をです・ます調の丁寧語で統一する。',
        hint: '一番ハズさない。迷ったらこれ。' },
      { v: 'kudaketa', l: '親しみやすい話し言葉',
        brief: '文章は話しかけるような口語にする。硬い言い回しや漢語を避ける。',
        hint: '距離が近い。個人店・常連商売向け。' },
      { v: 'kippari', l: 'きっぱり短く',
        brief: '一文を短く切り、言い切る。接続詞を減らし、修飾を削る。',
        hint: '歯切れがいい。読ませずに伝えたい時。' },
      { v: 'katame',  l: '職人らしく硬め',
        brief: '装飾を削ぎ、硬質で端正な書き言葉にする。一人称や感嘆を使わない。',
        hint: '技術で選ばれたい店向け。' },
      { v: 'jimoto',  l: '地元の言葉を少し',
        brief: '地の言葉や土地の呼び名を一言だけ織り交ぜ、距離を縮める。多用はしない。',
        hint: '地元客が主な店向け。使いすぎない加減で入れます。' }
    ]
  },
  {
    key: 'font',
    label: '文字 の 大きさ',
    note: '画面 の 文字 が 実際 に 大小 します',
    options: [
      { v: 'm',  l: '標準', scale: 1,    hint: 'そのまま。' },
      { v: 'l',  l: '大きめ（読みやすさ優先）', scale: 1.14,
        brief: '文字は大きめにして読みやすさを優先する。一文は短くする。',
        hint: '全体を 1.14 倍。スマホで読む客が多い店に。' },
      { v: 'xl', l: 'とても大きい（年配のお客さん向け）', scale: 1.3,
        brief: '文字をかなり大きくし、年配の方でも読めるようにする。一文を短く、漢字と横文字を減らす。',
        hint: '全体を 1.3 倍。文章も自動でやさしい言葉になります。' },
      { v: 's',  l: '小さめ（洗練）', scale: 0.92,
        brief: '文字は小さめで、余白を活かした洗練された見た目にする。',
        hint: '全体を 0.92 倍。余白で見せるデザイン向け。' }
    ]
  },
  {
    key: 'color',
    label: '色づかい',
    note: '画面 の 色 が 実際 に 変わります',
    options: [
      { v: 'auto',     l: 'おまかせ（テイストの色のまま）', hint: 'テイスト で 決まった 色 を そのまま 使います。' },
      { v: 'colorful', l: 'カラフルに', filter: 'saturate(1.35)',
        brief: '色数を多めに、明るい配色で楽しい印象にする。', hint: '色を鮮やかに振ります。' },
      { v: 'calm',     l: '落ち着いた色に', filter: 'saturate(0.72)',
        brief: '彩度を抑えた落ち着いた配色にする。', hint: '色味を抑えます。' },
      { v: 'mono',     l: 'モノトーン', filter: 'grayscale(0.92)',
        brief: 'ほぼ白黒のモノトーンでまとめる。', hint: 'ほぼ白黒に。写真も色が抜けます。' },
      { v: 'warm',     l: '暖色（赤・橙）', filter: 'sepia(0.22) saturate(1.25) hue-rotate(-12deg)',
        brief: '暖色を主役にした温かい配色にする。', hint: '全体を暖色に寄せます。' },
      { v: 'cool',     l: '寒色（青・緑）', filter: 'saturate(1.05) hue-rotate(18deg)',
        brief: '寒色を主役にした涼しげで清潔な配色にする。', hint: '全体を寒色に寄せます。' }
    ]
  },
  {
    key: 'photo',
    label: '写真 の 使い方',
    note: '写真 の 枚数 が 実際 に 変わります',
    options: [
      { v: 'auto', l: 'おまかせ（6 枚）', hint: 'ギャラリー 6 枚 の 標準 構成。' },
      { v: 'many', l: '写真たっぷり（9 枚）',
        brief: '写真を主役にして、文章は短く添える程度にする。',
        hint: 'ギャラリー 9 枚。内観や作例が多い店向け。' },
      { v: 'hero', l: '大きな1枚で見せる',
        brief: '冒頭に大きな写真を1枚置いて印象づけ、以降は落ち着いた構成にする。',
        hint: '冒頭を全画面に。ギャラリーは省きます。' },
      { v: 'few',  l: '写真少なめ・文字中心',
        brief: '写真は控えめにして、文章で伝える構成にする。',
        hint: 'ギャラリーを省きます。写真が少ない店向け。' }
    ]
  },
  {
    key: 'age',
    label: 'お客さん の 年齢層',
    note: '言葉 の 選び方 が 変わります',
    options: [
      { v: 'auto',   l: 'おまかせ', hint: '特に 寄せません。' },
      { v: '10_20',  l: '10〜20代', brief: '10〜20代に向けて、テンポの良いくだけた言葉づかいにする。', hint: '軽快に。流行りの言い回しは入れません。' },
      { v: '30_40',  l: '30〜40代', brief: '30〜40代に向けて、実利が伝わる落ち着いた言葉づかいにする。', hint: '時間やコスパの利点が前に出ます。' },
      { v: '50_60',  l: '50〜60代', brief: '50〜60代に向けて、丁寧で安心感のある言葉づかいにする。', hint: '落ち着いた語り口に。' },
      { v: '70',     l: '70代以上', brief: '70代以上に向けて、やさしい言葉で、専門用語と横文字を避ける。', hint: 'カタカナを減らし、やさしい言葉に。' },
      { v: 'family', l: 'ファミリー', brief: '家族連れに向けて、子ども連れでも安心できる点が伝わる書き方にする。', hint: '子連れ歓迎の点が前に出ます。' }
    ]
  },
  {
    key: 'amount',
    label: 'ページ の 情報量',
    note: '本文 の 長さ が 変わります',
    options: [
      { v: 'std',    l: '標準', hint: 'そのまま。' },
      { v: 'simple', l: 'シンプル（要点だけ）', brief: '情報を絞り、見出しと要点だけで完結させる。本文は短く。', hint: '読ませずに伝える構成。' },
      { v: 'rich',   l: 'しっかり説明', brief: 'サービス内容や来店の流れをしっかり説明し、疑問が残らないようにする。', hint: '初めての客の不安を潰す構成。' }
    ]
  },
  {
    key: 'cta',
    label: 'いちばん して ほしい 行動',
    note: '導線 の 押し出し が 変わります',
    options: [
      { v: 'auto',    l: 'おまかせ', hint: '電話 を 基本 に 置きます。' },
      { v: 'tel',     l: '電話してほしい',   brief: '電話での問い合わせを一番目立たせる。', hint: '電話番号を主役に。' },
      { v: 'reserve', l: '予約してほしい',   brief: '予約への導線を一番目立たせる。', hint: '予約ボタンを主役に。' },
      { v: 'line',    l: 'LINE 登録してほしい', brief: 'LINE の友だち追加を一番目立たせる。', hint: 'LINE 追加を主役に。' },
      { v: 'visit',   l: '来店してほしい',   brief: '場所・行き方・駐車場など、来店に必要な情報を目立たせる。', hint: '道順・駐車場を主役に。' }
    ]
  }
];

// 何も 選ば れて いない 時 の 土台 (これ 単体 でも 20 文字 以上 = AI 生成 が 通る)
const ML_DESIGN_BASE =
  'その店にしかない具体を書き、「地域で愛される」「お客様の笑顔」のような業界のテンプレ表現は使わない。' +
  '客が迷わず電話・予約までたどり着ける情報設計を優先する。';

function mlDesignDefaults() {
  const d = {};
  ML_DESIGN_GROUPS.forEach((g) => { d[g.key] = g.options[0].v; });
  return d;
}

function mlDesignOption(groupKey, value) {
  const g = ML_DESIGN_GROUPS.find((x) => x.key === groupKey);
  if (!g) return null;
  return g.options.find((o) => o.v === value) || g.options[0];
}

function mlPickedCount(sel) {
  return ML_DESIGN_GROUPS.filter((g) => {
    const o = mlDesignOption(g.key, (sel || {})[g.key]);
    return o && o.brief;
  }).length;
}

// 選択 → AI へ の 指示文
function mlBuildDesignBrief(sel, freeText) {
  const lines = [];
  ML_DESIGN_GROUPS.forEach((g) => {
    const o = mlDesignOption(g.key, (sel || {})[g.key]);
    if (o && o.brief) lines.push('・' + o.brief);
  });
  let out = ML_DESIGN_BASE;
  if (lines.length) out += '\n\n【この案件で指定されたデザイン方針】\n' + lines.join('\n');
  const free = (freeText || '').trim();
  if (free) out += '\n\n【補足（自由記入）】\n' + free;
  return out;
}

// 選択 → preview の 見た目
function mlDesignVisual(sel) {
  const s = sel || {};
  const vibe = mlDesignOption('vibe', s.vibe);
  const color = mlDesignOption('color', s.color);
  const font = mlDesignOption('font', s.font);
  return {
    style: (vibe && vibe.style) || null,
    filter: (color && color.filter) || 'none',
    scale: (font && font.scale) || 1,
    photo: s.photo || 'auto'
  };
}

// ==== 共通 UI: プルダウン を 描く ====
function mlRenderDesignSelects(container, sel, opts) {
  if (!container) return;
  const compact = !!(opts && opts.compact);
  container.innerHTML = ML_DESIGN_GROUPS.map((g) => {
    const cur = (sel || {})[g.key] || g.options[0].v;
    const o = mlDesignOption(g.key, cur);
    const id = 'dgsel-' + g.key;
    return `
      <div class="dg">
        <label class="dg-label" for="${id}">${g.label}</label>
        ${compact || !g.note ? '' : `<div class="dg-note">${g.note}</div>`}
        <select class="dg-select" id="${id}" data-group="${g.key}">
          ${g.options.map((op) => `<option value="${op.v}"${op.v === cur ? ' selected' : ''}>${op.l}</option>`).join('')}
        </select>
        <div class="dg-hint" data-hint="${g.key}">${mlHintHtml(o)}</div>
      </div>`;
  }).join('');
}

function mlHintHtml(o) {
  if (!o) return '';
  const hint = o.hint ? `<span class="dg-hint-main">${o.hint}</span>` : '';
  const ex = o.ex ? `<span class="dg-hint-ex">例：${o.ex}</span>` : '';
  return hint + ex;
}

function mlUpdateHint(container, groupKey, value) {
  if (!container) return;
  const el = container.querySelector(`[data-hint="${groupKey}"]`);
  if (el) el.innerHTML = mlHintHtml(mlDesignOption(groupKey, value));
}

if (typeof self !== 'undefined') {
  self.ML_DESIGN_GROUPS = ML_DESIGN_GROUPS;
  self.ML_DESIGN_BASE = ML_DESIGN_BASE;
  self.mlDesignDefaults = mlDesignDefaults;
  self.mlDesignOption = mlDesignOption;
  self.mlPickedCount = mlPickedCount;
  self.mlBuildDesignBrief = mlBuildDesignBrief;
  self.mlDesignVisual = mlDesignVisual;
  self.mlRenderDesignSelects = mlRenderDesignSelects;
  self.mlUpdateHint = mlUpdateHint;
}

// ==== 店 ごと の 前提条件 も 選択式 に (v2.8.0) ====
// 以前 は 自由 記入 の テキスト 欄 だった。 よく 効く 条件 を プルダウン に した。
const ML_STORE_GROUPS = [
  {
    key: 'access',
    label: 'お客さん の 来 方',
    options: [
      { v: 'auto', l: 'おまかせ' },
      { v: 'eki',  l: '駅から近い（歩いて来る）', brief: '客は駅から歩いて来る。駅からの近さを活かした書き方にする。' },
      { v: 'car',  l: '車で来る（駐車場あり）',   brief: '客は車で来る。駐車場があることと行きやすさを前に出す。' },
      { v: 'jutaku', l: '住宅街の中',            brief: '住宅街の中にある店。近所の人が通いで来る前提で書く。' },
      { v: 'shoten', l: '商店街・繁華街',        brief: '商店街や繁華街にある店。通りがかりの客も想定した書き方にする。' },
      { v: 'roadside', l: '郊外・ロードサイド',  brief: '郊外のロードサイド店。わざわざ来る価値が伝わる書き方にする。' }
    ]
  },
  {
    key: 'busy',
    label: '混み やすい 時間',
    options: [
      { v: 'auto',  l: 'おまかせ' },
      { v: 'hirubi', l: '平日の昼',   brief: '平日の昼が混む。それ以外の時間帯の空きを案内する書き方にする。' },
      { v: 'doni',  l: '土日',        brief: '土日が混む。平日の来店を促す書き方にする。' },
      { v: 'yugata', l: '夕方以降',   brief: '夕方以降が混む。日中の空きを案内する書き方にする。' },
      { v: 'asa',   l: '朝いちばん',  brief: '朝いちばんが混む。日中の空きを案内する書き方にする。' },
      { v: 'flat',  l: '特に偏りなし', brief: '時間帯の偏りは少ない。いつでも入りやすいことを伝える。' }
    ]
  },
  {
    key: 'booking',
    label: '予約 の しかた',
    options: [
      { v: 'auto',  l: 'おまかせ' },
      { v: 'kanzen', l: '完全予約制',          brief: '完全予約制。予約が必須であることを分かりやすく示す。' },
      { v: 'yusen', l: '予約優先（飛び込みも可）', brief: '予約優先だが飛び込みも受ける。どちらも可能なことを明記する。' },
      { v: 'fuyo',  l: '予約不要・いつでも',    brief: '予約不要でいつでも入れる。気軽さを前に出す。' },
      { v: 'touji', l: '当日予約OK',           brief: '当日予約も受ける。思い立った日に行けることを前に出す。' }
    ]
  },
  {
    key: 'target',
    label: 'いま 増やし たい お客さん',
    options: [
      { v: 'auto',  l: 'おまかせ' },
      { v: 'shinki', l: '新規の客',        brief: '新規客を増やしたい。初めてでも入りやすい点を丁寧に書く。' },
      { v: 'repeat', l: '常連の来店回数',  brief: '常連の来店頻度を上げたい。通う理由が積み上がる書き方にする。' },
      { v: 'shokai', l: '紹介',            brief: '紹介を増やしたい。人に話したくなる具体を入れる。' },
      { v: 'tanka',  l: '客単価の高い客',  brief: '単価の高い客を狙う。こだわりや手間の掛け方を具体で示す。' },
      { v: 'heijitsu', l: '平日の客',      brief: '平日の客を増やしたい。平日に来る利点を具体で示す。' }
    ]
  },
  {
    key: 'strength',
    label: 'この 店 の 押し どころ',
    options: [
      { v: 'auto',  l: 'おまかせ' },
      { v: 'gijutsu', l: '技術・腕',        brief: 'この店の押しどころは技術。腕と経験が伝わる具体を中心に据える。' },
      { v: 'kakaku',  l: '価格の手頃さ',    brief: 'この店の押しどころは価格の手頃さ。ただし具体的な金額は書かない。' },
      { v: 'basho',   l: '立地・駐車場',    brief: 'この店の押しどころは行きやすさ。立地と駐車場を中心に据える。' },
      { v: 'kositsu', l: '個室・プライベート感', brief: 'この店の押しどころは個室やプライベート感。人目を気にせず過ごせる点を中心に据える。' },
      { v: 'hitogara', l: 'スタッフの人柄', brief: 'この店の押しどころはスタッフの人柄。話しやすさと相談しやすさを中心に据える。' },
      { v: 'setsubi', l: '設備が新しい',    brief: 'この店の押しどころは設備の新しさ。清潔さと快適さを中心に据える。' },
      { v: 'jikan',   l: '営業時間が長い',  brief: 'この店の押しどころは営業時間の長さ。仕事帰りでも寄れる点を中心に据える。' },
      { v: 'kodomo',  l: '子ども連れ歓迎',  brief: 'この店の押しどころは子ども連れでも来られること。親が安心できる点を中心に据える。' }
    ]
  }
];

function mlStoreDefaults() {
  const d = {};
  ML_STORE_GROUPS.forEach((g) => { d[g.key] = g.options[0].v; });
  return d;
}

function mlStoreOption(groupKey, value) {
  const g = ML_STORE_GROUPS.find((x) => x.key === groupKey);
  if (!g) return null;
  return g.options.find((o) => o.v === value) || g.options[0];
}

function mlStorePickedCount(sel) {
  return ML_STORE_GROUPS.filter((g) => {
    const o = mlStoreOption(g.key, (sel || {})[g.key]);
    return o && o.brief;
  }).length;
}

// 店 ごと の 選択 + 自由 記入 → perStoreContext の 文
function mlBuildStoreBrief(sel, freeText) {
  const lines = [];
  ML_STORE_GROUPS.forEach((g) => {
    const o = mlStoreOption(g.key, (sel || {})[g.key]);
    if (o && o.brief) lines.push('・' + o.brief);
  });
  const free = (freeText || '').trim();
  if (lines.length === 0 && !free) return '';
  let out = lines.join('\n');
  if (free) out += (out ? '\n' : '') + '・' + free;
  return out;
}

function mlRenderStoreSelects(container, sel) {
  if (!container) return;
  container.innerHTML = ML_STORE_GROUPS.map((g) => {
    const cur = (sel || {})[g.key] || g.options[0].v;
    const id = 'stsel-' + g.key;
    return `
      <div class="st">
        <label class="st-label" for="${id}">${g.label}</label>
        <select class="st-select" id="${id}" data-group="${g.key}">
          ${g.options.map((op) => `<option value="${op.v}"${op.v === cur ? ' selected' : ''}>${op.l}</option>`).join('')}
        </select>
      </div>`;
  }).join('');
}

if (typeof self !== 'undefined') {
  self.ML_STORE_GROUPS = ML_STORE_GROUPS;
  self.mlStoreDefaults = mlStoreDefaults;
  self.mlStoreOption = mlStoreOption;
  self.mlStorePickedCount = mlStorePickedCount;
  self.mlBuildStoreBrief = mlBuildStoreBrief;
  self.mlRenderStoreSelects = mlRenderStoreSelects;
}
