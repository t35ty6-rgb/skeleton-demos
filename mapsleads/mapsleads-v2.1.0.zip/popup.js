// MapsLeads popup UI (v2.0.0 · Places API 版)
const els = {};
[
  'zip', 'zipStatus',
  'pref', 'city', 'town',
  'categoryPreset', 'categoryText',
  'storeName',
  'queryPreview',
  'fNoWeb', 'fInsta', 'fLine',
  'volume', 'enrichSocial',
  'start', 'stop', 'reset', 'csv', 'copy', 'mockup',
  'total', 'hit', 'noweb', 'progress', 'msg',
  'licenseStatus', 'btnRegisterKey', 'btnResetKey',
  'quotaSearch', 'quotaPhoto', 'quotaSearchBar', 'quotaPhotoBar',
  'philosophy', 'philosophyStatus', 'btnSavePhilosophy', 'btnClearPhilosophy'
].forEach((id) => { els[id] = document.getElementById(id); });

let currentRows = [];
let zipDebounce = null;
let currentMode = 'area';

// ==== mode 切替 ====
function initModeTabs() {
  document.querySelectorAll('.mode-tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      const mode = tab.dataset.mode;
      setMode(mode);
      saveState();
    });
  });
}
function setMode(mode) {
  currentMode = mode;
  document.querySelectorAll('.mode-tab').forEach((t) => t.classList.toggle('active', t.dataset.mode === mode));
  document.querySelectorAll('.mode-panel').forEach((p) => p.classList.remove('active'));
  const panel = mode === 'storeName' ? 'panelStoreName' : 'panelArea';
  document.getElementById(panel).classList.add('active');
  updateQuery();
}

// ==== 地域 selects ====
function buildRegionSelects() {
  Object.keys(window.MAPS_REGIONS).forEach((p) => {
    const o = document.createElement('option'); o.value = p; o.textContent = p;
    els.pref.appendChild(o);
  });
  window.MAPS_CATEGORIES.forEach((c) => {
    const o = document.createElement('option'); o.value = c; o.textContent = c;
    els.categoryPreset.appendChild(o);
  });

  els.pref.addEventListener('change', () => {
    fillCities(els.pref.value);
    saveState(); updateQuery();
  });
  els.city.addEventListener('change', () => { saveState(); updateQuery(); });
  els.town.addEventListener('input', () => { saveState(); updateQuery(); });
  els.categoryPreset.addEventListener('change', () => {
    if (els.categoryPreset.value) els.categoryText.value = els.categoryPreset.value;
    saveState(); updateQuery();
  });
  els.categoryText.addEventListener('input', () => { saveState(); updateQuery(); });
  els.storeName.addEventListener('input', () => { saveState(); updateQuery(); });
}

function fillCities(pref) {
  els.city.innerHTML = '<option value="">選択</option>';
  const cities = window.MAPS_REGIONS[pref] || [];
  cities.forEach((c) => {
    const o = document.createElement('option'); o.value = c; o.textContent = c;
    els.city.appendChild(o);
  });
}

// ==== 郵便番号 → 住所 ====
async function lookupZip(raw) {
  const zip = String(raw || '').replace(/[^\d]/g, '');
  if (zip.length !== 7) {
    els.zipStatus.textContent = zip.length === 0 ? '' : `${zip.length}/7桁`;
    els.zipStatus.className = 'zip-status';
    return;
  }
  els.zipStatus.textContent = '検索中…';
  els.zipStatus.className = 'zip-status';
  try {
    const r = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${zip}`);
    const j = await r.json();
    if (!j.results || !j.results.length) {
      els.zipStatus.textContent = '該当なし';
      els.zipStatus.className = 'zip-status err';
      return;
    }
    const a = j.results[0];
    const pref = a.address1;
    const city = a.address2;
    const town = a.address3 || '';
    if (![...els.pref.options].some((o) => o.value === pref)) {
      const o = document.createElement('option'); o.value = pref; o.textContent = pref;
      els.pref.appendChild(o);
    }
    els.pref.value = pref;
    fillCities(pref);
    if (![...els.city.options].some((o) => o.value === city)) {
      const o = document.createElement('option'); o.value = city; o.textContent = city;
      els.city.appendChild(o);
    }
    els.city.value = city;
    els.town.value = town;
    els.zipStatus.textContent = `${pref} ${city} ${town}`;
    els.zipStatus.className = 'zip-status ok';
    saveState(); updateQuery();
  } catch (e) {
    els.zipStatus.textContent = `エラー: ${e.message.slice(0, 40)}`;
    els.zipStatus.className = 'zip-status err';
  }
}

function currentQuery() {
  if (currentMode === 'storeName') {
    return (els.storeName.value || '').trim();
  }
  const p = els.pref.value || '';
  const c = els.city.value || '';
  const t = (els.town.value || '').trim();
  const cat = (els.categoryText.value || els.categoryPreset.value || '').trim();
  return [p, c, t, cat].filter(Boolean).join(' ');
}
function updateQuery() {
  const q = currentQuery();
  if (q) {
    els.queryPreview.textContent = `検索 クエリ: ${q}`;
    els.queryPreview.classList.add('filled');
  } else {
    els.queryPreview.textContent = '検索 クエリ: -';
    els.queryPreview.classList.remove('filled');
  }
}

// ==== state ====
function saveState() {
  chrome.storage.local.set({
    ml_state_v2: {
      mode: currentMode,
      zip: els.zip.value,
      pref: els.pref.value, city: els.city.value, town: els.town.value,
      categoryPreset: els.categoryPreset.value, categoryText: els.categoryText.value,
      storeName: els.storeName.value,
      fNoWeb: els.fNoWeb.checked, fInsta: els.fInsta.checked, fLine: els.fLine.checked,
      volume: els.volume.value, enrichSocial: els.enrichSocial.value
    }
  });
}
async function loadState() {
  const { ml_state_v2, ml_state } = await chrome.storage.local.get(['ml_state_v2', 'ml_state']);
  const st = ml_state_v2 || ml_state;
  if (!st) return;
  if (st.mode) setMode(st.mode);
  els.zip.value = st.zip || '';
  els.pref.value = st.pref || '';
  if (els.pref.value) fillCities(els.pref.value);
  els.city.value = st.city || '';
  els.town.value = st.town || '';
  els.categoryPreset.value = st.categoryPreset || '';
  els.categoryText.value = st.categoryText || '';
  els.storeName.value = st.storeName || '';
  els.fNoWeb.checked = st.fNoWeb !== false;
  els.fInsta.checked = !!st.fInsta;
  els.fLine.checked = !!st.fLine;
  if (st.volume) els.volume.value = st.volume;
  if (st.enrichSocial != null) els.enrichSocial.value = String(st.enrichSocial);
  updateQuery();
}

// ==== License ====
async function promptForLicense() {
  const key = prompt(
    `無料 トライアル は ${MapsLeadsLicense.TRIAL_LIMIT} 検索 まで。\n\n継続 には ライセンスキー が 必要 です。\n購入: sales@skeleton-inc.jp\n\nお持ちの方 は キー を 入力:`
  );
  if (!key) return false;
  const res = await MapsLeadsLicense.registerLicense(key);
  if (!res.ok) { alert(res.error); return false; }
  return true;
}
async function showLicenseStatus() {
  try {
    const st = await MapsLeadsLicense.status();
    if (st.licensed) return `ライセンス 登録済 (bind: ${(st.boundAt || '').slice(0,10)})`;
    if (st.hasLicense && !st.boundHere) return '別 PC で 使用中';
    if (st.hasLicense && !st.licensed) return 'キー が 無効化 されて います';
    return `無料 トライアル ${st.trialUsed}/${st.trialLimit}`;
  } catch (_) { return ''; }
}

// ==== quota 表示 ====
function renderQuota(quota) {
  if (!quota) {
    els.quotaSearch.parentElement.parentElement.style.display = 'none';
    return;
  }
  document.getElementById('quotaBox').style.display = 'block';
  // Server returns quota in various shapes: search/photo objects OR single number for current op
  if (quota.search && typeof quota.search === 'object') {
    els.quotaSearch.textContent = `${quota.search.used} / ${quota.search.cap}`;
    els.quotaSearchBar.style.width = `${Math.min(100, (quota.search.used / quota.search.cap) * 100)}%`;
    els.quotaSearchBar.classList.toggle('warn', quota.search.used / quota.search.cap > 0.8);
    els.quotaSearchBar.classList.toggle('full', quota.search.used / quota.search.cap >= 1);
  } else if (typeof quota.used === 'number') {
    // 直前 検索 の 使用量 (単一 op result)
    els.quotaSearch.textContent = `${quota.used} / ${quota.cap}`;
    els.quotaSearchBar.style.width = `${Math.min(100, (quota.used / quota.cap) * 100)}%`;
  }
  if (quota.photo && typeof quota.photo === 'object') {
    els.quotaPhoto.textContent = `${quota.photo.used} / ${quota.photo.cap}`;
    els.quotaPhotoBar.style.width = `${Math.min(100, (quota.photo.used / quota.photo.cap) * 100)}%`;
    els.quotaPhotoBar.classList.toggle('warn', quota.photo.used / quota.photo.cap > 0.8);
    els.quotaPhotoBar.classList.toggle('full', quota.photo.used / quota.photo.cap >= 1);
  }
}

async function fetchServerQuota() {
  try {
    const res = await bg({ type: 'LICENSE_VERIFY_SERVER' });
    if (res && res.ok && res.status && res.status.quota) {
      renderQuota(res.status.quota);
    }
  } catch (_) {}
}

// ==== 表示 ====
function setMsg(text, err = false) {
  els.msg.textContent = text;
  els.msg.classList.toggle('err', !!err);
}
function passFilters(r) {
  if (els.fNoWeb.checked && r.hasOwnWebsite) return false;
  if (els.fInsta.checked && !r.hasInstagram) return false;
  if (els.fLine.checked && !r.hasLineOfficial) return false;
  return true;
}
function renderStat(rows) {
  els.total.textContent = rows.length;
  els.hit.textContent = rows.filter(passFilters).length;
  els.noweb.textContent = rows.filter((r) => !r.hasOwnWebsite).length;
  // CSV · コピー · サイト案 は 「全 件」 出力 なので、 rows があれば 押せる
  const anyRow = rows.length > 0;
  els.csv.disabled = !anyRow;
  els.copy.disabled = !anyRow;
  if (els.mockup) els.mockup.disabled = !anyRow;
  const box = document.getElementById('statBox');
  if (box) box.classList.toggle('empty', rows.length === 0);
}

// ==== 出力 ====
const COLS = ['name', 'category', 'rating', 'reviewCount', 'phone', 'addressFull', 'area', 'hours', 'website', 'hasOwnWebsite', 'websiteIsBookingOnly', 'instagramUrl', 'lineUrl', 'hasInstagram', 'hasLineOfficial', 'mapsUrl'];
const HEAD = ['店名', '業種', '評価', 'レビュー数', '電話', '住所', 'エリア', '営業状態', 'ウェブサイト', '自社HP有', '予約サイトのみ', 'Instagram URL', 'LINE URL', 'Insta有', '公式LINE有', 'Maps URL'];
function toCSV(rows) {
  const esc = (v) => {
    const s = String(v == null ? '' : (typeof v === 'boolean' ? (v ? '○' : '') : v));
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return '﻿' + [HEAD.join(','), ...rows.map((r) => COLS.map((c) => esc(r[c])).join(','))].join('\r\n');
}
function toTSV(rows) {
  const clean = (v) => String(v == null ? '' : (typeof v === 'boolean' ? (v ? '○' : '') : v)).replace(/\t/g, ' ').replace(/\r?\n/g, ' ');
  return [HEAD.join('\t'), ...rows.map((r) => COLS.map((c) => clean(r[c])).join('\t'))].join('\n');
}

// ==== bg 通信 ====
function bg(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(res);
    });
  });
}
// 実行中 phase set: これらの 間 は start は disabled · stop は enabled
const RUNNING_PHASES = new Set(['starting', 'searching', 'search_done', 'enrich']);
const TERMINAL_PHASES = new Set(['done', 'stopped', 'cap_exceeded', 'license_error', 'error']);

function applyRunState(phase) {
  const running = RUNNING_PHASES.has(phase);
  const terminal = TERMINAL_PHASES.has(phase) || phase === 'idle';
  els.start.disabled = running;
  els.stop.disabled = !running;
  if (terminal) {
    els.start.disabled = false;
    els.stop.disabled = true;
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'BG_PROGRESS') {
    const p = msg.progress || {};
    let s = '待機中';
    if (p.phase === 'starting') s = '起動中…';
    else if (p.phase === 'searching') s = `検索 中 ${p.current}/${p.total || '?'}`;
    else if (p.phase === 'search_done') s = `検索 完了 ${p.total} 件`;
    else if (p.phase === 'enrich') s = `SNS 補完 ${p.current}/${p.total} · ${p.msg || ''}`;
    else if (p.phase === 'skip_enrich') s = `SNS 補完 スキップ ${p.total} 件`;
    else if (p.phase === 'done') s = `完了 · ${p.total} 件`;
    else if (p.phase === 'stopped') s = '停止 しました';
    else if (p.phase === 'cap_exceeded') s = '今月 の 上限 に 達しました';
    else if (p.phase === 'license_error') s = 'ライセンス エラー';
    else if (p.phase === 'error') s = `エラー: ${p.msg}`;
    else if (p.phase === 'idle') s = '待機中';
    els.progress.textContent = s;
    applyRunState(p.phase);
    if (msg.quota) renderQuota(msg.quota);
    if (p.phase === 'done' || p.phase === 'stopped' || p.phase === 'cap_exceeded' || p.phase === 'error') {
      loadResultFromBg();
      fetchServerQuota();
    }
  }
});
async function loadResultFromBg() {
  try {
    const res = await bg({ type: 'BG_RESULT' });
    if (res && res.ok) {
      currentRows = res.rows || [];
      renderStat(currentRows);
      if (res.quota) renderQuota(res.quota);
      setMsg(`結果: total ${currentRows.length} 件 / 条件 hit ${currentRows.filter(passFilters).length} 件`);
    }
  } catch (_) {}
}

// ==== ハンドラ ====
els.zip.addEventListener('input', () => {
  clearTimeout(zipDebounce);
  saveState();
  zipDebounce = setTimeout(() => lookupZip(els.zip.value), 500);
});

els.start.addEventListener('click', async () => {
  setMsg('');
  const q = currentQuery();
  if (!q) {
    setMsg(currentMode === 'storeName' ? '店名 を 入力 して' : 'エリア と 業種 を 選んで', true);
    return;
  }

  applyRunState('starting');
  currentRows = [];
  renderStat(currentRows);
  els.progress.textContent = '起動…';

  const maxResults = parseInt(els.volume.value, 10) || 40;
  const enrichSocial = els.enrichSocial.value === '1';

  const payload = {
    mode: currentMode,
    maxResults,
    enrichSocial
  };
  if (currentMode === 'storeName') {
    payload.storeName = els.storeName.value.trim();
  } else {
    const area = [els.pref.value, els.city.value, (els.town.value || '').trim()].filter(Boolean).join(' ');
    const category = (els.categoryText.value || els.categoryPreset.value || '').trim();
    payload.area = area;
    payload.category = category;
  }

  try {
    const res = await bg({ type: 'BG_START', payload });
    if (!res || !res.ok) {
      if (res && res.error === 'license_denied') {
        const reason = res.reason;
        if (reason === 'trial_exhausted') {
          const got = await promptForLicense();
          if (got) setMsg('ライセンス 登録 完了。 もう 一度 「収集 を 開始」 を 押して ください。');
          else setMsg('ライセンス 未登録 の ため 実行 できません', true);
        } else if (reason === 'revoked') {
          setMsg('ライセンスキー が 無効化 されて います。 owner (sales@skeleton-inc.jp) に 連絡 して ください。', true);
        } else if (reason === 'other_pc') {
          setMsg('この キー は 別 の PC で 使用中 です。 owner に 依頼 して bind 解除 して ください。', true);
        } else if (reason === 'invalid_key_format') {
          setMsg('ライセンスキー の 形式 が 不正 です', true);
        } else {
          setMsg('ライセンス 検証 エラー: ' + reason, true);
        }
        applyRunState('idle');
        return;
      }
      throw new Error((res && res.error) || '起動失敗');
    }
    const st = await showLicenseStatus();
    setMsg('検索 中… (' + st + ' · popup 閉じても 継続)');
  } catch (e) {
    setMsg(`エラー: ${e.message}`, true);
    applyRunState('error');
  }
});

els.stop.addEventListener('click', async () => {
  try { await bg({ type: 'BG_STOP' }); setMsg('停止 しました'); }
  catch (e) { setMsg(`停止 失敗: ${e.message}`, true); }
});

els.reset.addEventListener('click', () => {
  currentRows = []; renderStat(currentRows); els.progress.textContent = '待機中'; setMsg('');
  applyRunState('idle');
});

[els.fNoWeb, els.fInsta, els.fLine].forEach((el) => {
  el.addEventListener('change', () => { renderStat(currentRows); saveState(); });
});

els.csv.addEventListener('click', async () => {
  const rows = currentRows;
  if (!rows.length) { setMsg('該当 0 件', true); return; }
  const csv = toCSV(rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const dt = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const q = currentQuery().replace(/\s+/g, '_');
  try {
    await chrome.downloads.download({ url, filename: `mapsleads-${q || 'result'}-${dt}.csv`, saveAs: true });
    setMsg(`${rows.length} 件 CSV 出力 (全 件)`);
  } catch (e) { setMsg(`DL 失敗: ${e.message}`, true); }
});
els.copy.addEventListener('click', async () => {
  const rows = currentRows;
  if (!rows.length) { setMsg('該当 0 件', true); return; }
  try { await navigator.clipboard.writeText(toTSV(rows)); setMsg(`${rows.length} 件 コピー (全 件、 スプシ に Cmd+V)`); }
  catch (e) { setMsg(`コピー 失敗: ${e.message}`, true); }
});

if (els.mockup) {
  els.mockup.addEventListener('click', async () => {
    const rows = currentRows;
    if (!rows.length) { setMsg('該当 0 件', true); return; }
    try {
      await chrome.storage.session.set({ ml_mockup_rows: rows });
    } catch (e) {
      try { await chrome.storage.local.set({ ml_mockup_rows: rows }); }
      catch (e2) { setMsg(`データ 保存 失敗: ${e2.message}`, true); return; }
    }
    const url = chrome.runtime.getURL('mockup.html');
    try {
      await chrome.tabs.create({ url });
      setMsg(`${rows.length} 件 の サイト 案 タブ を 開き ました`);
    } catch (e) {
      setMsg(`タブ 生成 失敗: ${e.message}`, true);
    }
  });
}

[els.volume, els.enrichSocial].forEach((el) => el.addEventListener('change', saveState));

// ==== philosophy ====
async function loadPhilosophy() {
  if (!els.philosophy) return;
  const { ml_philosophy } = await chrome.storage.local.get('ml_philosophy');
  if (ml_philosophy && typeof ml_philosophy.text === 'string') {
    els.philosophy.value = ml_philosophy.text;
    updatePhilosophyStatus(ml_philosophy.text, ml_philosophy.savedAt);
  }
}

function updatePhilosophyStatus(text, savedAt) {
  if (!els.philosophyStatus) return;
  const len = (text || '').trim().length;
  if (len === 0) {
    els.philosophyStatus.textContent = '未 入力 の 場合 は 業種 別 の 汎用 テンプレ で 生成 します';
    els.philosophyStatus.style.color = '';
  } else if (len < 20) {
    els.philosophyStatus.textContent = `${len} / 20 文字 (最低 20 文字 必要)`;
    els.philosophyStatus.style.color = 'var(--accent)';
  } else if (len > 8000) {
    els.philosophyStatus.textContent = `${len} / 8000 文字 (超過)`;
    els.philosophyStatus.style.color = 'var(--accent)';
  } else {
    const at = savedAt ? new Date(savedAt).toLocaleString('ja-JP', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '未 保存';
    els.philosophyStatus.textContent = `${len} 文字 · 保存: ${at}`;
    els.philosophyStatus.style.color = 'var(--ok)';
  }
}

async function savePhilosophy() {
  const text = (els.philosophy.value || '').trim();
  if (text.length > 0 && text.length < 20) {
    alert('最低 20 文字 は 必要 です');
    return;
  }
  if (text.length > 8000) {
    alert('8000 文字 を 超えて います');
    return;
  }
  const savedAt = Date.now();
  await chrome.storage.local.set({ ml_philosophy: { text, savedAt } });
  updatePhilosophyStatus(text, savedAt);
  setMsg('制作会社 の 考え方 を 保存 しました');
}

async function clearPhilosophy() {
  if (!confirm('保存 した 考え方 を 削除 して 汎用 テンプレ に 戻します。 続行?')) return;
  els.philosophy.value = '';
  await chrome.storage.local.remove('ml_philosophy');
  updatePhilosophyStatus('', null);
  setMsg('考え方 を クリア しました');
}

async function refreshLicenseIndicator() {
  if (!els.licenseStatus) return;
  const st = await showLicenseStatus();
  els.licenseStatus.textContent = st || '状態不明';
}
if (els.btnRegisterKey) {
  els.btnRegisterKey.addEventListener('click', async () => {
    const got = await promptForLicense();
    if (got) setMsg('ライセンス 登録 完了。');
    await refreshLicenseIndicator();
    await fetchServerQuota();
  });
}
if (els.btnResetKey) {
  els.btnResetKey.addEventListener('click', async () => {
    if (!confirm('ライセンス と トライアル 記録 を リセット します。 続行?')) return;
    await MapsLeadsLicense.reset();
    setMsg('リセット 完了。');
    await refreshLicenseIndicator();
  });
}

if (els.btnSavePhilosophy) {
  els.btnSavePhilosophy.addEventListener('click', savePhilosophy);
}
if (els.btnClearPhilosophy) {
  els.btnClearPhilosophy.addEventListener('click', clearPhilosophy);
}
if (els.philosophy) {
  els.philosophy.addEventListener('input', () => updatePhilosophyStatus(els.philosophy.value, null));
}

// init
(async () => {
  initModeTabs();
  buildRegionSelects();
  await loadState();
  await loadPhilosophy();
  updateQuery();
  refreshLicenseIndicator();
  fetchServerQuota();
  try {
    const status = await bg({ type: 'BG_STATUS' });
    if (status && status.ok) {
      if (status.running) {
        setMsg('検索 中… (完了 まで お待ちを)');
        applyRunState(status.progress?.phase || 'searching');
        els.progress.textContent = status.progress
          ? `${status.progress.phase} ${status.progress.current}/${status.progress.total || '?'}`
          : '進行中';
      } else if (status.rows > 0) {
        await loadResultFromBg();
      } else {
        try {
          const { ml_last_result } = await chrome.storage.local.get('ml_last_result');
          if (ml_last_result && Array.isArray(ml_last_result.rows) && ml_last_result.rows.length) {
            currentRows = ml_last_result.rows;
            renderStat(currentRows);
            if (ml_last_result.quota) renderQuota(ml_last_result.quota);
            const at = ml_last_result.at ? new Date(ml_last_result.at).toLocaleString('ja-JP', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
            setMsg(`前回 の 結果 (${at}): ${currentRows.length} 件 · 条件 hit ${currentRows.filter(passFilters).length} 件`);
            if (els.progress) els.progress.textContent = `復元: ${currentRows.length} 件`;
          }
        } catch (_) {}
      }
    }
  } catch (_) {}
})();
