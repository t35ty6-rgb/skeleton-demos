// MapsLeads backend endpoint config
// project: skeleton-mapsleads-2026 / region: asia-northeast1
const MAPSLEADS_API = {
  BASE: 'https://asia-northeast1-skeleton-mapsleads-2026.cloudfunctions.net',
  ENDPOINTS: {
    searchStores: '/searchStores',
    getPhoto: '/getPhoto',
    enrichSocial: '/enrichSocial',
    verifyLicense: '/verifyLicense'
  }
};

if (typeof self !== 'undefined') self.MAPSLEADS_API = MAPSLEADS_API;
if (typeof window !== 'undefined') window.MAPSLEADS_API = MAPSLEADS_API;
