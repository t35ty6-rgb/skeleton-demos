// MapsLeads license module (v0.5.0)
// Client-side hardening:
//   - PC fingerprint (navigator+tz+hardware) SHA-256 → pcId (SW/popup 両context 互換 で screen不使用)
//   - License key に pcId を bind (chrome.storage.local に 暗号化 保存)
//   - Revocation list check (GitHub Pages JSON, 24h cache)
//   - Trial counter は pcId 派生 key で AES-GCM 暗号化 保存 (storage clear で reset を 検知)
//
// これは client 側 の 防御。 完全な crack 耐性 は server verify で 実現、 それは Phase 2。

(function (root) {
  const REVOCATION_URL = 'https://t35ty6-rgb.github.io/skeleton-demos/mapsleads/revoked-keys.json';
  const TRIAL_LIMIT = 5;
  const REVOCATION_TTL_MS = 24 * 60 * 60 * 1000; // 24h

  // ==== PC fingerprint ====
  // SW context と popup context 両方で 動く 必要 → screen / DOM API は 使わない
  // navigator + Intl のみ で 構成 (両 context で 同一 hash に なる)
  async function generatePcId() {
    const source = [
      navigator.userAgent || '',
      (navigator.userAgentData && navigator.userAgentData.platform) || '',
      (navigator.languages || (navigator.language ? [navigator.language] : [])).join(','),
      String(navigator.hardwareConcurrency || 0),
      String(navigator.deviceMemory || 0),
      Intl.DateTimeFormat().resolvedOptions().timeZone || '',
    ].join('|');
    const buf = new TextEncoder().encode(source);
    const hashBuf = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(hashBuf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  // ==== 暗号化 (pcId 派生 key で AES-GCM) ====
  async function deriveKey(pcId) {
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode('ml-v05-' + pcId),
      'PBKDF2',
      false,
      ['deriveKey'],
    );
    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: new TextEncoder().encode('mapsleads-2026'),
        iterations: 10000,
        hash: 'SHA-256',
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt'],
    );
  }
  async function encryptStr(pcId, plaintext) {
    const key = await deriveKey(pcId);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const enc = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      new TextEncoder().encode(plaintext),
    );
    return { iv: Array.from(iv), ct: Array.from(new Uint8Array(enc)) };
  }
  async function decryptStr(pcId, packet) {
    try {
      const key = await deriveKey(pcId);
      const dec = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: new Uint8Array(packet.iv) },
        key,
        new Uint8Array(packet.ct),
      );
      return new TextDecoder().decode(dec);
    } catch (_) {
      return null;
    }
  }

  // ==== キー validity (checksum) ====
  function isKeyFormatValid(key) {
    if (!key || typeof key !== 'string') return false;
    const m = key.trim().match(/^ML-([A-Z0-9]{12})$/);
    if (!m) return false;
    let sum = 0;
    for (const c of m[1]) sum += c.charCodeAt(0);
    return sum % 9 === 0;
  }

  // ==== Revocation list ====
  async function fetchRevocationList() {
    const { ml_revoked_cache } = await chrome.storage.local.get('ml_revoked_cache');
    if (ml_revoked_cache && ml_revoked_cache.at && Date.now() - ml_revoked_cache.at < REVOCATION_TTL_MS) {
      return ml_revoked_cache.list || [];
    }
    try {
      const r = await fetch(REVOCATION_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      const list = Array.isArray(j.revoked) ? j.revoked : [];
      await chrome.storage.local.set({ ml_revoked_cache: { at: Date.now(), list } });
      return list;
    } catch (_) {
      // fetch fail → 前回 cache が あれば 使う、 無ければ 空 リスト
      return (ml_revoked_cache && ml_revoked_cache.list) || [];
    }
  }
  async function isRevoked(key) {
    const list = await fetchRevocationList();
    return list.includes(key);
  }

  // ==== License state (bind + trial) ====
  // ml_state_v5 に 暗号化 保存: { license, boundPcId, trialUsed, boundAt }
  async function loadState(pcId) {
    const { ml_state_v5 } = await chrome.storage.local.get('ml_state_v5');
    if (!ml_state_v5) return { license: null, boundPcId: null, trialUsed: 0, boundAt: null };
    const dec = await decryptStr(pcId, ml_state_v5);
    if (!dec) return { license: null, boundPcId: null, trialUsed: 0, boundAt: null };
    try {
      return JSON.parse(dec);
    } catch (_) {
      return { license: null, boundPcId: null, trialUsed: 0, boundAt: null };
    }
  }
  async function saveState(pcId, state) {
    const packet = await encryptStr(pcId, JSON.stringify(state));
    await chrome.storage.local.set({ ml_state_v5: packet });
  }

  // ==== 検証 API (拡張 の 収集開始 で 呼ぶ) ====
  // 戻り値: { allowed: bool, reason?: string, trialRemaining?: number, needKey?: bool }
  async function checkAndConsume() {
    const pcId = await generatePcId();
    const state = await loadState(pcId);

    // (1) license 未設定 → trial 判定
    if (!state.license) {
      if (state.trialUsed >= TRIAL_LIMIT) {
        return { allowed: false, reason: 'trial_exhausted', needKey: true };
      }
      // trial 消費
      state.trialUsed = (state.trialUsed || 0) + 1;
      await saveState(pcId, state);
      return { allowed: true, trialRemaining: TRIAL_LIMIT - state.trialUsed };
    }

    // (2) license 設定済 → format + revocation + bind 判定
    if (!isKeyFormatValid(state.license)) {
      return { allowed: false, reason: 'invalid_key_format', needKey: true };
    }
    if (await isRevoked(state.license)) {
      return { allowed: false, reason: 'revoked', needKey: false, revokedKey: state.license };
    }
    if (state.boundPcId && state.boundPcId !== pcId) {
      // 別 PC で bind されてた → この 端末では 使えない
      // (現在の端末で state が残ってる = 過去にここでも使ってた が pcId が変わった可能性、
      //  UA/hw変更 or 別インストール で 別PCID)
      return { allowed: false, reason: 'other_pc', needKey: false };
    }
    if (!state.boundPcId) {
      // 初回 bind
      state.boundPcId = pcId;
      state.boundAt = new Date().toISOString();
      await saveState(pcId, state);
    }
    return { allowed: true, licensed: true };
  }

  // license 手入力 (owner から 受領した key)
  async function registerLicense(key) {
    const pcId = await generatePcId();
    const trimmed = String(key || '').trim();
    if (!isKeyFormatValid(trimmed)) return { ok: false, error: 'ライセンスキーの形式が違います (ML-XXXXXXXXXXXX)' };
    if (await isRevoked(trimmed)) return { ok: false, error: 'このキーは無効化されています。 owner に連絡してください。' };
    const state = await loadState(pcId);
    state.license = trimmed;
    state.boundPcId = pcId;
    state.boundAt = new Date().toISOString();
    await saveState(pcId, state);
    return { ok: true, boundAt: state.boundAt, pcId };
  }

  // reset (owner 用 debug)
  async function reset() {
    await chrome.storage.local.remove(['ml_state_v5', 'ml_revoked_cache']);
  }

  // API proxy 呼び出し 用: license key の 生 文字列 を 返す
  async function getKey() {
    const pcId = await generatePcId();
    const state = await loadState(pcId);
    return state.license || null;
  }

  // 状態取得 (popup 表示 用)
  async function status() {
    const pcId = await generatePcId();
    const state = await loadState(pcId);
    const licensed = !!(state.license && isKeyFormatValid(state.license) && !(await isRevoked(state.license)));
    return {
      pcId: pcId.slice(0, 12) + '…',
      hasLicense: !!state.license,
      licensed,
      trialUsed: state.trialUsed || 0,
      trialLimit: TRIAL_LIMIT,
      boundAt: state.boundAt,
      boundHere: !state.boundPcId || state.boundPcId === pcId,
    };
  }

  // export
  root.MapsLeadsLicense = {
    generatePcId,
    isKeyFormatValid,
    fetchRevocationList,
    isRevoked,
    checkAndConsume,
    registerLicense,
    reset,
    status,
    getKey,
    TRIAL_LIMIT,
  };
})(typeof self !== 'undefined' ? self : globalThis);
