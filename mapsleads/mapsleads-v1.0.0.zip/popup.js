// MapsLeads popup UI (v0.4 zipcode + preset)
const els = {};
[
  'zip', 'zipStatus',
  'pref', 'city', 'town',
  'categoryPreset', 'categoryText', 'queryPreview',
  'fNoWeb', 'fInsta', 'fLine',
  'volume', 'deepCheck', 'waitMs', 'maxScrolls',
  'start', 'stop', 'reset', 'csv', 'copy', 'mockup',
  'total', 'hit', 'noweb', 'progress', 'msg',
  'licenseStatus', 'btnRegisterKey', 'btnResetKey',
].forEach((id) => { els[id] = document.getElementById(id); });

let currentRows = [];
let zipDebounce = null;

// ==== プルダウン ====
function buildRegionSelects() {
  Object.keys(window.MAPS_REGIONS).forEach((p) => {
    const o = document.createElement('option'); o.value = p; o.textContent = p;
    els.pref.appendChild(o);
  });
  window.MAPS_CATEGORIES.forEach((c) => {
    const o = document.createElement('option'); o.value = c; o.textContent = c;
    els.categoryPreset.appendChild(o);
  });

  els.pref.addEventListener('change', () => {
    fillCities(els.pref.value);
    saveState(); updateQuery();
  });
  els.city.addEventListener('change', () => { saveState(); updateQuery(); });
  els.town.addEventListener('input', () => { saveState(); updateQuery(); });
  els.categoryPreset.addEventListener('change', () => {
    if (els.categoryPreset.value) els.categoryText.value = els.categoryPreset.value;
    saveState(); updateQuery();
  });
  els.categoryText.addEventListener('input', () => { saveState(); updateQuery(); });
}

function fillCities(pref) {
  els.city.innerHTML = '<option value="">選択</option>';
  const cities = window.MAPS_REGIONS[pref] || [];
  cities.forEach((c) => {
    const o = document.createElement('option'); o.value = c; o.textContent = c;
    els.city.appendChild(o);
  });
}

// ==== 郵便番号 → 住所 ====
async function lookupZip(raw) {
  const zip = String(raw || '').replace(/[^\d]/g, '');
  if (zip.length !== 7) {
    els.zipStatus.textContent = zip.length === 0 ? '' : `${zip.length}/7桁`;
    els.zipStatus.className = 'zip-status';
    return;
  }
  els.zipStatus.textContent = '検索中…';
  els.zipStatus.className = 'zip-status';
  try {
    const r = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${zip}`);
    const j = await r.json();
    if (!j.results || !j.results.length) {
      els.zipStatus.textContent = '該当なし';
      els.zipStatus.className = 'zip-status err';
      return;
    }
    const a = j.results[0];
    const pref = a.address1;
    const city = a.address2;
    const town = a.address3 || '';
    // pref 選択肢に 無い → 追加
    if (![...els.pref.options].some((o) => o.value === pref)) {
      const o = document.createElement('option'); o.value = pref; o.textContent = pref;
      els.pref.appendChild(o);
    }
    els.pref.value = pref;
    fillCities(pref);
    // city も 無ければ 追加
    if (![...els.city.options].some((o) => o.value === city)) {
      const o = document.createElement('option'); o.value = city; o.textContent = city;
      els.city.appendChild(o);
    }
    els.city.value = city;
    els.town.value = town;
    els.zipStatus.textContent = `${pref} ${city} ${town}`;
    els.zipStatus.className = 'zip-status ok';
    saveState(); updateQuery();
  } catch (e) {
    els.zipStatus.textContent = `エラー: ${e.message.slice(0, 40)}`;
    els.zipStatus.className = 'zip-status err';
  }
}

function currentQuery() {
  const p = els.pref.value || '';
  const c = els.city.value || '';
  const t = (els.town.value || '').trim();
  const cat = (els.categoryText.value || els.categoryPreset.value || '').trim();
  return [p, c, t, cat].filter(Boolean).join(' ');
}
function updateQuery() {
  const q = currentQuery();
  if (q) {
    els.queryPreview.textContent = `検索クエリ: ${q}`;
    els.queryPreview.classList.add('filled');
  } else {
    els.queryPreview.textContent = '検索クエリ: -';
    els.queryPreview.classList.remove('filled');
  }
}

// ==== state ====
function saveState() {
  chrome.storage.local.set({
    ml_state: {
      zip: els.zip.value,
      pref: els.pref.value, city: els.city.value, town: els.town.value,
      categoryPreset: els.categoryPreset.value, categoryText: els.categoryText.value,
      fNoWeb: els.fNoWeb.checked, fInsta: els.fInsta.checked, fLine: els.fLine.checked,
      volume: els.volume.value, deepCheck: els.deepCheck.value,
      waitMs: els.waitMs.value, maxScrolls: els.maxScrolls.value,
    },
  });
}
async function loadState() {
  const { ml_state } = await chrome.storage.local.get('ml_state');
  if (!ml_state) return;
  els.zip.value = ml_state.zip || '';
  els.pref.value = ml_state.pref || '';
  if (els.pref.value) fillCities(els.pref.value);
  els.city.value = ml_state.city || '';
  els.town.value = ml_state.town || '';
  els.categoryPreset.value = ml_state.categoryPreset || '';
  els.categoryText.value = ml_state.categoryText || '';
  els.fNoWeb.checked = ml_state.fNoWeb !== false;
  els.fInsta.checked = !!ml_state.fInsta;
  els.fLine.checked = !!ml_state.fLine;
  if (ml_state.volume) els.volume.value = ml_state.volume;
  if (ml_state.deepCheck) els.deepCheck.value = ml_state.deepCheck;
  if (ml_state.waitMs) els.waitMs.value = ml_state.waitMs;
  if (ml_state.maxScrolls) els.maxScrolls.value = ml_state.maxScrolls;
  updateQuery();
}

// ==== License (v0.5 hardened: pcId bind + revocation) ====
async function promptForLicense() {
  const key = prompt(
    `無料トライアルは ${MapsLeadsLicense.TRIAL_LIMIT} 検索まで。\n\n継続にはライセンスキーが必要です。\n購入: sales@skeleton-inc.jp\n\nお持ちの方はキーを入力:`
  );
  if (!key) return false;
  const res = await MapsLeadsLicense.registerLicense(key);
  if (!res.ok) { alert(res.error); return false; }
  return true;
}
async function showLicenseStatus() {
  try {
    const st = await MapsLeadsLicense.status();
    let s = '';
    if (st.licensed) s = `✓ ライセンス済 (${st.boundAt ? 'bind:' + st.boundAt.slice(0,10) : ''})`;
    else if (st.hasLicense && !st.boundHere) s = '⚠ 別PCで使用中';
    else if (st.hasLicense && !st.licensed) s = '✗ キー無効化';
    else s = `無料トライアル ${st.trialUsed}/${st.trialLimit}`;
    return s;
  } catch (_) { return ''; }
}

// ==== 表示 ====
function setMsg(text, err = false) {
  els.msg.textContent = text;
  els.msg.classList.toggle('err', !!err);
}
function passFilters(r) {
  if (els.fNoWeb.checked && r.hasOwnWebsite) return false;
  if (els.fInsta.checked && !r.hasInstagram) return false;
  if (els.fLine.checked && !r.hasLineOfficial) return false;
  return true;
}
function renderStat(rows) {
  els.total.textContent = rows.length;
  els.hit.textContent = rows.filter(passFilters).length;
  els.noweb.textContent = rows.filter((r) => !r.hasOwnWebsite).length;
  const any = rows.filter(passFilters).length > 0;
  els.csv.disabled = !any;
  els.copy.disabled = !any;
  if (els.mockup) els.mockup.disabled = !any;
}

// ==== 出力 ====
const COLS = ['name', 'category', 'rating', 'reviewCount', 'phone', 'addressFull', 'area', 'hours', 'website', 'hasOwnWebsite', 'websiteIsBookingOnly', 'instagramUrl', 'lineUrl', 'hasInstagram', 'hasLineOfficial', 'mapsUrl'];
const HEAD = ['店名', '業種', '評価', 'レビュー数', '電話', '住所', 'エリア', '営業状態', 'ウェブサイト', '自社HP有', '予約サイトのみ', 'Instagram URL', 'LINE URL', 'Insta有', '公式LINE有', 'Maps URL'];
function toCSV(rows) {
  const esc = (v) => {
    const s = String(v == null ? '' : (typeof v === 'boolean' ? (v ? '○' : '') : v));
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return '﻿' + [HEAD.join(','), ...rows.map((r) => COLS.map((c) => esc(r[c])).join(','))].join('\r\n');
}
function toTSV(rows) {
  const clean = (v) => String(v == null ? '' : (typeof v === 'boolean' ? (v ? '○' : '') : v)).replace(/\t/g, ' ').replace(/\r?\n/g, ' ');
  return [HEAD.join('\t'), ...rows.map((r) => COLS.map((c) => clean(r[c])).join('\t'))].join('\n');
}

// ==== bg 通信 ====
function bg(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(res);
    });
  });
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'BG_PROGRESS') {
    const p = msg.progress || {};
    let s = '待機中';
    if (p.phase === 'starting') s = '起動中…';
    else if (p.phase === 'serp_scroll') s = `[1/2] 地図を クロール中 ${p.current}/${p.total || '?'}`;
    else if (p.phase === 'serp_done') s = `[1/2] 地図から ${p.total}件 発見 → 詳細確認 へ`;
    else if (p.phase === 'detail') s = `[2/2] 詳細確認 ${p.current}/${p.total} : ${p.msg || ''}`;
    else if (p.phase === 'skip_detail') s = `速さ優先モード · ${p.total}件 (詳細スキップ)`;
    else if (p.phase === 'done') s = `完了 · ${p.total}件`;
    else if (p.phase === 'stopped') s = '停止しました';
    else if (p.phase === 'error') s = `エラー: ${p.msg}`;
    else if (p.phase === 'idle') s = '待機中';
    els.progress.textContent = s;
    if (p.phase === 'done' || p.phase === 'stopped') loadResultFromBg();
  }
});
async function loadResultFromBg() {
  try {
    const res = await bg({ type: 'BG_RESULT' });
    if (res && res.ok) {
      currentRows = res.rows || [];
      renderStat(currentRows);
      setMsg(`結果: total ${currentRows.length} 件 / 条件hit ${currentRows.filter(passFilters).length} 件`);
    }
  } catch (_) {}
}

// ==== ハンドラ ====
els.zip.addEventListener('input', () => {
  clearTimeout(zipDebounce);
  saveState();
  zipDebounce = setTimeout(() => lookupZip(els.zip.value), 500);
});

els.start.addEventListener('click', async () => {
  setMsg('');
  const q = currentQuery();
  if (!q) { setMsg('エリア と 業種 を 選んで', true); return; }

  els.start.disabled = true;
  els.stop.disabled = false;
  currentRows = [];
  renderStat(currentRows);
  els.progress.textContent = '起動…';

  // 取得件数 プリセット → maxScrolls
  const maxScrollsOverride = parseInt(els.maxScrolls.value, 10);
  const volumeMap = { '10': 10, '20': 20, '40': 40, '80': 80 };
  const maxScrolls = (maxScrollsOverride > 0)
    ? maxScrollsOverride
    : (volumeMap[els.volume.value] || 40);

  try {
    const res = await bg({
      type: 'BG_START',
      payload: {
        query: q,
        maxScrolls,
        waitMs: parseInt(els.waitMs.value, 10) || 1200,
        deepCheck: els.deepCheck.value === '1',
        filters: { fNoWeb: els.fNoWeb.checked, fInsta: els.fInsta.checked, fLine: els.fLine.checked },
      },
    });
    if (!res || !res.ok) {
      if (res && res.error === 'license_denied') {
        const reason = res.reason;
        if (reason === 'trial_exhausted') {
          const got = await promptForLicense();
          if (got) { setMsg('ライセンス登録完了。 もう一度「収集を 開始」を押してください。'); }
          else { setMsg('ライセンス未登録のため実行できません', true); }
        } else if (reason === 'revoked') {
          setMsg('ライセンスキーが無効化されています。 owner (sales@skeleton-inc.jp) に連絡してください。', true);
        } else if (reason === 'other_pc') {
          setMsg('このキーは別のPCで使用中です。 owner に依頼して bind を解除してもらってください。', true);
        } else if (reason === 'invalid_key_format') {
          setMsg('ライセンスキーの形式が正しくありません。', true);
        } else {
          setMsg('ライセンス検証エラー: ' + reason, true);
        }
        return;
      }
      throw new Error(res && res.error || '起動失敗');
    }
    const st = await showLicenseStatus();
    setMsg('裏で 作業中… (' + st + ' · popup 閉じても 継続)');
  } catch (e) {
    setMsg(`エラー: ${e.message}`, true);
  } finally {
    els.start.disabled = false;
    els.stop.disabled = true;
  }
});

els.stop.addEventListener('click', async () => {
  try { await bg({ type: 'BG_STOP' }); setMsg('停止しました'); }
  catch (e) { setMsg(`停止失敗: ${e.message}`, true); }
});

els.reset.addEventListener('click', () => {
  currentRows = []; renderStat(currentRows); els.progress.textContent = '待機中'; setMsg('');
});

[els.fNoWeb, els.fInsta, els.fLine].forEach((el) => {
  el.addEventListener('change', () => { renderStat(currentRows); saveState(); });
});

els.csv.addEventListener('click', async () => {
  const rows = currentRows.filter(passFilters);
  if (!rows.length) { setMsg('該当 0 件', true); return; }
  const csv = toCSV(rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const dt = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const q = currentQuery().replace(/\s+/g, '_');
  try {
    await chrome.downloads.download({ url, filename: `mapsleads-${q || 'result'}-${dt}.csv`, saveAs: true });
    setMsg(`${rows.length} 件 CSV 出力`);
  } catch (e) { setMsg(`DL 失敗: ${e.message}`, true); }
});
els.copy.addEventListener('click', async () => {
  const rows = currentRows.filter(passFilters);
  if (!rows.length) { setMsg('該当 0 件', true); return; }
  try { await navigator.clipboard.writeText(toTSV(rows)); setMsg(`${rows.length} 件 コピー (スプシに Cmd+V)`); }
  catch (e) { setMsg(`コピー 失敗: ${e.message}`, true); }
});

if (els.mockup) {
  els.mockup.addEventListener('click', async () => {
    const rows = currentRows.filter(passFilters);
    if (!rows.length) { setMsg('該当 0 件', true); return; }
    // storage.session に 保存 (拡張ID scope 内 で 別 tab から Read 可能)
    try {
      await chrome.storage.session.set({ ml_mockup_rows: rows });
    } catch (e) {
      // storage.session 使えない 環境 は local に fallback
      try { await chrome.storage.local.set({ ml_mockup_rows: rows }); }
      catch (e2) { setMsg(`データ 保存 失敗: ${e2.message}`, true); return; }
    }
    const url = chrome.runtime.getURL('mockup.html');
    try {
      await chrome.tabs.create({ url });
      setMsg(`${rows.length} 件 のサイト案 生成 タブ を 開きました`);
    } catch (e) {
      setMsg(`タブ 生成 失敗: ${e.message}`, true);
    }
  });
}

[els.volume, els.deepCheck, els.waitMs, els.maxScrolls].forEach((el) => el.addEventListener('change', saveState));

// license status refresh
async function refreshLicenseIndicator() {
  if (!els.licenseStatus) return;
  const st = await showLicenseStatus();
  els.licenseStatus.textContent = st || '状態不明';
}
if (els.btnRegisterKey) {
  els.btnRegisterKey.addEventListener('click', async () => {
    const got = await promptForLicense();
    if (got) { setMsg('ライセンス登録完了。'); }
    await refreshLicenseIndicator();
  });
}
if (els.btnResetKey) {
  els.btnResetKey.addEventListener('click', async () => {
    if (!confirm('ライセンス と トライアル記録 を リセット します。 続行？')) return;
    await MapsLeadsLicense.reset();
    setMsg('リセット 完了。');
    await refreshLicenseIndicator();
  });
}

// init
(async () => {
  buildRegionSelects();
  await loadState();
  updateQuery();
  refreshLicenseIndicator();
  try {
    const status = await bg({ type: 'BG_STATUS' });
    if (status && status.ok) {
      if (status.running) {
        setMsg('裏で 作業中… (完了 まで お待ちを)');
        els.progress.textContent = status.progress
          ? `${status.progress.phase} ${status.progress.current}/${status.progress.total || '?'}`
          : '進行中';
      } else if (status.rows > 0) {
        await loadResultFromBg();
      }
    }
  } catch (_) {}
})();
