// MapsLeads content script (v0.3)
// dual mode: SERP (/maps/search/) と Place (/maps/place/) を URL で判定
// - SERP_COLLECT: 検索結果 パネル を scroll し カード基本情報 収集
// - PLACE_EXTRACT: 詳細パネル から phone/website/insta/line 抽出

(function () {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ==== 共通: 同意 dialog 自動 dismiss ====
  async function dismissConsent() {
    const texts = ['すべて受け入れる', '同意する', 'Accept all', 'I agree'];
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
    for (const b of btns) {
      const t = (b.textContent || '').trim();
      if (texts.some((x) => t.includes(x))) {
        try { b.click(); await sleep(500); return true; } catch (_) {}
      }
    }
    return false;
  }

  async function waitForResultsPanel(timeoutMs = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      await dismissConsent();
      const p = document.querySelector('div[role="feed"]');
      if (p) return p;
      await sleep(300);
    }
    return null;
  }

  // ==== SERP モード ====
  function findResultsPanel() {
    return document.querySelector('div[role="feed"]');
  }

  function extractCardContainers(panel) {
    const anchors = panel.querySelectorAll('a.hfpxzc');
    const cards = [];
    const seen = new Set();
    anchors.forEach((a) => {
      let card = a;
      for (let i = 0; i < 8; i++) {
        if (!card.parentElement) break;
        card = card.parentElement;
        if (card.classList && card.classList.contains('Nv2PK')) break;
      }
      if (!card || seen.has(card)) return;
      seen.add(card);
      cards.push({ card, anchor: a });
    });
    return cards;
  }

  function parseCardBasic({ card, anchor }) {
    const row = {
      name: '',
      rating: '',
      reviewCount: '',
      category: '',
      area: '',
      hours: '',
      mapsUrl: '',
    };
    // Google Maps は visited link に aria-label suffix「・アクセスしたリンク」を 付ける ので 除去
    row.name = (anchor.getAttribute('aria-label') || '').replace(/\s*[・·]\s*アクセスしたリンク\s*$/, '').trim();
    row.mapsUrl = anchor.href || '';

    const ratingSpan = card.querySelector('span[role="img"][aria-label*="星"], span[role="img"][aria-label*="star"]');
    if (ratingSpan) {
      const lbl = ratingSpan.getAttribute('aria-label') || '';
      const m = lbl.match(/([0-9.]+)/);
      if (m) row.rating = m[1];
      const rc = lbl.match(/([0-9,]+)\s*件/) || lbl.match(/([0-9,]+)\s*review/i);
      if (rc) row.reviewCount = rc[1].replace(/,/g, '');
    }

    const metas = Array.from(card.querySelectorAll('.W4Efsd'))
      .map((d) => (d.textContent || '').replace(/\s+/g, ' ').trim())
      .filter(Boolean);

    // 「category · area」だけの最短 line を探す (rating や hours を除外)
    let bestCatArea = '';
    for (const t of metas) {
      if (/^[0-9.]+$/.test(t)) continue;
      if (/^(営業中|営業時間外|定休日|24)/.test(t)) continue;
      if (!bestCatArea || t.length < bestCatArea.length) bestCatArea = t;
    }
    if (bestCatArea) {
      const parts = bestCatArea.split(/[·・]/).map((s) => s.trim()).filter(Boolean);
      if (parts.length >= 1) row.category = parts[0];
      if (parts.length >= 2) row.area = parts.slice(1).join(' ').trim();
    }
    for (const t of metas) {
      const h = t.match(/(営業中|営業時間外|定休日|24 時間営業|24時間営業|一時休業|閉業)[^|·]*/);
      if (h) { row.hours = h[0].trim(); break; }
    }
    return row;
  }

  async function serpCollect({ maxScrolls = 40, waitMs = 1200 }) {
    const panel = await waitForResultsPanel(15000);
    if (!panel) throw new Error('SERP パネル未検出 (15秒待っても role="feed" が出ませんでした)');
    // mapsUrl の query/hash を 落とした pathname を dedup key に 使う (visited/history パラメータ違い で 重複 防止)
    const normalizeMapsUrl = (url) => {
      try {
        const u = new URL(url);
        // /maps/place/{name}/{coords}/data=... の /data 以降 も 落とす
        return u.origin + u.pathname.replace(/\/data=.*$/, '');
      } catch (_) { return url; }
    };
    const collected = new Map();
    let lastCount = -1;
    let stagnant = 0;
    for (let i = 0; i < maxScrolls; i++) {
      const cards = extractCardContainers(panel);
      cards.forEach((c) => {
        const b = parseCardBasic(c);
        if (!b.name || !b.mapsUrl) return;
        const key = b.name + '::' + normalizeMapsUrl(b.mapsUrl);
        if (!collected.has(key)) collected.set(key, b);
      });
      // progress をパッシブに投げる (受信側の有無に関わらず fire and forget)
      try { chrome.runtime.sendMessage({ type: 'CS_SERP_PROGRESS', scroll: i + 1, max: maxScrolls, count: collected.size }); } catch (_) {}
      if (panel.textContent.includes('結果は以上です') || panel.textContent.includes("You've reached the end")) break;
      panel.scrollTop = panel.scrollHeight;
      await sleep(waitMs);
      if (collected.size === lastCount) {
        stagnant++;
        if (stagnant >= 3) break;
      } else {
        stagnant = 0;
        lastCount = collected.size;
      }
    }
    return Array.from(collected.values());
  }

  // ==== Place モード ====
  async function waitForPlaceReady(name, timeoutMs = 10000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      await dismissConsent();
      // Place ページ は authority link or 電話 button が出ることで 「詳細ロード完了」 判定
      const main = document.querySelector('div[role="main"]');
      if (main) {
        const h1 = main.querySelector('h1');
        const hasAuthority = main.querySelector('a[data-item-id="authority"]');
        const hasPhone = main.querySelector('button[data-item-id^="phone:tel:"]');
        const hasAddress = main.querySelector('button[data-item-id="address"]');
        if (h1 && h1.textContent && h1.textContent.trim().length >= 1) {
          if (hasAuthority || hasPhone || hasAddress) return true;
          const t = h1.textContent.trim();
          if (name && name.length >= 3 && t.includes(name.slice(0, Math.min(name.length, 4)))) return true;
        }
      }
      await sleep(300);
    }
    return false;
  }

  // 「自社 HP」 じゃない 予約 / ポータル サイト の hostname (これらは HP無し扱い)
  const BOOKING_HOSTS = [
    'beauty.hotpepper.jp', 'hotpepper.jp', 'beauty.rakuten.co.jp',
    'reserva.be', 'coubic.com', 'airrsv.net', 'select-type.com',
    'salons.jp', 'salontown.jp', 'minimo.jp', 'reserv.jp',
    'tabelog.com', 'gnavi.co.jp', 'hitosara.com', 'r.gnavi.co.jp',
    'jalan.net', 'rurubu.travel', 'ikyu.com',
    'goo.gl', 'bit.ly', 't.co', 'x.gd',
    'facebook.com', 'm.facebook.com',
    'instagram.com',
    'x.com', 'twitter.com',
    'line.me', 'lin.ee',
    'docs.google.com',
    'ameblo.jp', 'amebaownd.com',
  ];
  // URL に 含まれてたら HP 無し 扱い (弱一致、 複数ドメイン持つ サービス 用)
  const BOOKING_SUBSTRINGS = [
    'ameba',
    'utage',
  ];
  function isBookingHost(url) {
    try {
      const u = new URL(url);
      const h = u.hostname.replace(/^www\./, '');
      if (BOOKING_HOSTS.some((b) => h === b || h.endsWith('.' + b))) return true;
      const lower = url.toLowerCase();
      if (BOOKING_SUBSTRINGS.some((s) => lower.includes(s))) return true;
      return false;
    } catch (_) { return false; }
  }

  function extractPlace() {
    const detail = {
      phone: '',
      website: '',
      websiteIsBookingOnly: false,
      hasOwnWebsite: false,
      addressFull: '',
      instagramUrl: '',
      lineUrl: '',
      hasInstagram: false,
      hasLineOfficial: false,
    };
    const main = document.querySelector('div[role="main"]');
    if (!main) return detail;

    // website
    const siteA = main.querySelector('a[data-item-id="authority"]');
    if (siteA && siteA.href && !siteA.href.startsWith('https://www.google.')) {
      detail.website = siteA.href;
    }
    // phone
    const phoneBtn = main.querySelector('button[data-item-id^="phone:tel:"]');
    if (phoneBtn) {
      const lbl = phoneBtn.getAttribute('aria-label') || phoneBtn.textContent || '';
      const m = lbl.match(/[0+][\d\-\s]{9,}/);
      if (m) detail.phone = m[0].replace(/\s+/g, '').replace(/^\+81[- ]?/, '0');
    }
    if (!detail.phone) {
      const telLink = main.querySelector('a[href^="tel:"]');
      if (telLink) {
        const h = telLink.getAttribute('href') || '';
        const raw = h.replace(/^tel:/, '');
        if (/^\d{10,11}$/.test(raw)) {
          // format 0X-YYYY-ZZZZ (簡易)
          if (raw.length === 11) detail.phone = raw.slice(0, 3) + '-' + raw.slice(3, 7) + '-' + raw.slice(7);
          else if (raw.length === 10) detail.phone = raw.slice(0, 2) + '-' + raw.slice(2, 6) + '-' + raw.slice(6);
        }
      }
    }
    // 住所
    const addrBtn = main.querySelector('button[data-item-id="address"]');
    if (addrBtn) {
      const lbl = addrBtn.getAttribute('aria-label') || addrBtn.textContent || '';
      detail.addressFull = lbl.replace(/^住所[::]?\s*/, '').trim();
    }
    // Insta/LINE: 全 a[href] を 走査
    const allLinks = Array.from(main.querySelectorAll('a[href]'));
    for (const a of allLinks) {
      const h = a.href || '';
      if (!h || h.startsWith('https://www.google.') || h.startsWith('https://maps.google.') || h.startsWith('https://support.google.')) continue;
      if (/instagram\.com\/(?!p\/)/i.test(h) && !detail.instagramUrl) {
        detail.instagramUrl = h;
        detail.hasInstagram = true;
      }
      // 公式 LINE アカウント (lin.ee 短縮 / liff.line.me / line.me/R/ti/p/)
      if (/(^|\.)lin\.ee\/|liff\.line\.me\/|line\.me\/R\/ti\/p\//i.test(h) && !detail.lineUrl) {
        detail.lineUrl = h;
        detail.hasLineOfficial = true;
      }
    }
    // website 欄 が Insta/LINE URL の 場合 も 拾う
    if (detail.website) {
      if (/instagram\.com/i.test(detail.website)) { detail.hasInstagram = true; if (!detail.instagramUrl) detail.instagramUrl = detail.website; }
      if (/(^|\.)lin\.ee\/|liff\.line\.me\/|line\.me\/R\/ti\/p\//i.test(detail.website)) { detail.hasLineOfficial = true; if (!detail.lineUrl) detail.lineUrl = detail.website; }
    }
    // 自社 HP 判定: website があり かつ 予約/ポータル ではない
    if (detail.website && !isBookingHost(detail.website)) {
      detail.hasOwnWebsite = true;
    } else if (detail.website) {
      detail.websiteIsBookingOnly = true;
    }
    return detail;
  }

  // ==== メッセージハンドラ ====
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        if (msg.type === 'PING') { sendResponse({ ok: true, url: location.href }); return; }
        if (msg.type === 'SERP_COLLECT') {
          if (!/\/maps\/search\//.test(location.pathname)) {
            sendResponse({ ok: false, error: 'SERP ページで実行してください: ' + location.href });
            return;
          }
          const rows = await serpCollect({ maxScrolls: msg.maxScrolls || 40, waitMs: msg.waitMs || 1200 });
          sendResponse({ ok: true, rows });
          return;
        }
        if (msg.type === 'PLACE_EXTRACT') {
          if (!/\/maps\/place\//.test(location.pathname)) {
            sendResponse({ ok: false, error: 'Place ページで実行してください: ' + location.href });
            return;
          }
          const ready = await waitForPlaceReady(msg.name || '', 10000);
          const detail = extractPlace();
          sendResponse({ ok: true, ready, detail });
          return;
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  });
})();
