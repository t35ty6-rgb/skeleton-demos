// MapsLeads · 抽象 素材 の 生成 (v2.11.0)
//
// なぜ これ が 要る か
//   これ まで 実写真 が 足り ない 分 を Unsplash の 「よそ の 店」 の 写真 で 埋めて いた。
//   提案 を 受け取った 店 から すると 自分 の 店 で ない 写真 が 並ぶ こと に なり、
//   そのまま 公開 されれば 事実 と 違う 見た目 に なる。
//   代わり に 「店 の 写真 の ふり を しない」 抽象 素材 を その場 で 作る。
//   外部 通信 ゼロ、 店 ごと に 決まった 絵 (店名 から 決定) が 出る。

const ART_PALETTES = {
  A: { bg: '#F4F6FB', a: '#0071E3', b: '#8B5CF6', c: '#EC4899', ink: '#0F1B2D' },
  B: { bg: '#141210', a: '#A88B45', b: '#6B5528', c: '#2A241B', ink: '#F5EFE2' },
  C: { bg: '#FFFFFF', a: '#D8DEE6', b: '#EDF1F5', c: '#C3CCD6', ink: '#1D1D1F' },
  D: { bg: '#F6EFE4', a: '#C46B3C', b: '#E0C9A6', c: '#8B6A45', ink: '#3B2C1E' },
  E: { bg: '#F7F4EE', a: '#C8102E', b: '#2F3A34', c: '#D8D2C4', ink: '#1E1B16' },
  F: { bg: '#121212', a: '#C9A96E', b: '#3A3A3A', c: '#1E1E1E', ink: '#F2EFE9' },
  G: { bg: '#FDF3F5', a: '#D4838A', b: '#F6D7DE', c: '#E9A9B4', ink: '#4A2B31' },
  H: { bg: '#101010', a: '#D80012', b: '#2A2A2A', c: '#7A000B', ink: '#FFFFFF' }
};

function artHash(str) {
  let h = 2166136261;
  const s = String(str || 'x');
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function artRand(seed) {
  let x = seed || 1;
  return () => {
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    return Math.abs(x % 100000) / 100000;
  };
}

// kind: hero (16:9) / about (4:3) / tile (4:3 小)
function mlArtDataUri(style, seedStr, kind, variant) {
  const p = ART_PALETTES[style] || ART_PALETTES.A;
  const W = kind === 'hero' ? 1600 : 1200;
  const H = kind === 'hero' ? 900 : 900;
  const rnd = artRand(artHash(seedStr + '|' + kind + '|' + (variant || 0)) % 2147483647);
  const dark = ['B', 'F', 'H'].includes(style);

  // 大きな ぼかし 円 を 3 つ。 位置 と 大きさ は 店 ごと に 決まる
  const blobs = [];
  for (let i = 0; i < 3; i++) {
    const cx = Math.round(W * (0.12 + rnd() * 0.76));
    const cy = Math.round(H * (0.12 + rnd() * 0.76));
    const r = Math.round(Math.min(W, H) * (0.28 + rnd() * 0.34));
    const fill = [p.a, p.b, p.c][i % 3];
    const op = dark ? 0.55 : 0.42;
    blobs.push(`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill}" opacity="${op}"/>`);
  }

  // 幾何 の 線 (style ごと に 表情 を 変える)
  let motif = '';
  if (style === 'E') {
    const n = 5 + Math.floor(rnd() * 3);
    for (let i = 1; i < n; i++) {
      const x = Math.round((W / n) * i);
      motif += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${p.ink}" stroke-opacity="0.10" stroke-width="2"/>`;
    }
  } else if (style === 'C') {
    const n = 7;
    for (let i = 1; i < n; i++) {
      const y = Math.round((H / n) * i);
      motif += `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${p.ink}" stroke-opacity="0.06" stroke-width="1"/>`;
    }
  } else if (style === 'H' || style === 'F') {
    const y = Math.round(H * (0.3 + rnd() * 0.4));
    motif += `<rect x="0" y="${y}" width="${W}" height="${Math.round(H * 0.06)}" fill="${p.a}" opacity="0.5"/>`;
  } else {
    const n = 3;
    for (let i = 0; i < n; i++) {
      const r = Math.round(Math.min(W, H) * (0.18 + i * 0.13));
      const cx = Math.round(W * (0.2 + rnd() * 0.6));
      const cy = Math.round(H * (0.2 + rnd() * 0.6));
      motif += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${p.ink}" stroke-opacity="0.09" stroke-width="2"/>`;
    }
  }

  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">` +
    `<defs>` +
      `<filter id="b" x="-25%" y="-25%" width="150%" height="150%">` +
        `<feGaussianBlur stdDeviation="${Math.round(Math.min(W, H) * 0.12)}"/>` +
      `</filter>` +
      `<filter id="g"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2"/>` +
        `<feColorMatrix type="saturate" values="0"/>` +
        `<feComponentTransfer><feFuncA type="linear" slope="${dark ? 0.10 : 0.07}"/></feComponentTransfer></filter>` +
    `</defs>` +
    `<rect width="${W}" height="${H}" fill="${p.bg}"/>` +
    `<g filter="url(#b)">${blobs.join('')}</g>` +
    motif +
    `<rect width="${W}" height="${H}" filter="url(#g)" opacity="0.9"/>` +
    `</svg>`;

  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}

if (typeof self !== 'undefined') {
  self.mlArtDataUri = mlArtDataUri;
  self.ML_ART_PALETTES = ART_PALETTES;
}
