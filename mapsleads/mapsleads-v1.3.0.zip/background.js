// MapsLeads - background service worker
importScripts('license.js');
// 最小化ウィンドウを開き、 SERP 収集 → 各 place URL を 順次 navigate → 詳細抽出 → 結果集約

const state = {
  running: false,
  windowId: null,
  tabId: null,
  rows: [], // 集約 (basic + detail merge)
  filters: null, // {pref, city, category, fNoWeb, fInsta, fLine}
  query: '',
  progress: { phase: 'idle', current: 0, total: 0, msg: '' },
  lastError: null,
};

function reset() {
  state.running = false;
  state.windowId = null;
  state.tabId = null;
  state.rows = [];
  state.progress = { phase: 'idle', current: 0, total: 0, msg: '' };
  state.lastError = null;
}

async function broadcastProgress() {
  try {
    await chrome.runtime.sendMessage({ type: 'BG_PROGRESS', progress: state.progress, count: state.rows.length });
  } catch (_) {}
  const t = state.progress;
  const badge = t.phase === 'idle' ? '' : `${t.current}/${t.total || '?'}`.slice(0, 6);
  try { chrome.action.setBadgeText({ text: badge }); } catch (_) {}
  try { chrome.action.setBadgeBackgroundColor({ color: '#0F1B2D' }); } catch (_) {}
}

async function updateProgress(phase, current, total, msg) {
  state.progress = { phase, current, total, msg: msg || '' };
  await broadcastProgress();
}

async function closeWindow() {
  if (state.windowId != null) {
    try { await chrome.windows.remove(state.windowId); } catch (_) {}
    state.windowId = null;
    state.tabId = null;
  }
}

// tab の loading complete を 待つ (URL が期待通り かつ status="complete")
function waitForTabComplete(tabId, expectUrlMatch, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const handler = (updatedTabId, info, tab) => {
      if (updatedTabId !== tabId) return;
      if (info.status === 'complete') {
        if (!expectUrlMatch || (tab.url && expectUrlMatch.test(tab.url))) {
          chrome.tabs.onUpdated.removeListener(handler);
          resolve(tab);
        }
      }
    };
    chrome.tabs.onUpdated.addListener(handler);
    const iv = setInterval(async () => {
      try {
        const t = await chrome.tabs.get(tabId);
        if (t && t.status === 'complete' && (!expectUrlMatch || expectUrlMatch.test(t.url || ''))) {
          clearInterval(iv);
          chrome.tabs.onUpdated.removeListener(handler);
          resolve(t);
        }
      } catch (_) {}
      if (Date.now() - start > timeoutMs) {
        clearInterval(iv);
        chrome.tabs.onUpdated.removeListener(handler);
        reject(new Error('tab load timeout'));
      }
    }, 400);
  });
}

async function ensureContentInjected(tabId) {
  try {
    await new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, { type: 'PING' }, (res) => {
        if (chrome.runtime.lastError || !res) reject(new Error('no ping'));
        else resolve(res);
      });
    });
    return;
  } catch (_) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    // give it a beat
    await new Promise((r) => setTimeout(r, 400));
  }
}

async function sendToTab(tabId, msg, timeoutMs = 60000) {
  return await new Promise((resolve, reject) => {
    let done = false;
    const t = setTimeout(() => { if (!done) { done = true; reject(new Error('sendToTab timeout')); } }, timeoutMs);
    try {
      chrome.tabs.sendMessage(tabId, msg, (res) => {
        if (done) return;
        done = true;
        clearTimeout(t);
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(res);
      });
    } catch (e) {
      done = true; clearTimeout(t); reject(e);
    }
  });
}

async function runJob({ query, maxScrolls, waitMs, filters, deepCheck = true }) {
  if (state.running) throw new Error('すでに実行中');
  reset();
  state.running = true;
  state.query = query;
  state.filters = filters;
  await updateProgress('starting', 0, 0, 'ウィンドウを開いています');

  // ウィンドウ を 開く (state:minimized は 単独で しか 使えない ので 2 段)
  const searchUrl = `https://www.google.com/maps/search/${encodeURIComponent(query)}`;
  const win = await chrome.windows.create({
    url: searchUrl,
    focused: false,
    width: 1280,
    height: 900,
  });
  state.windowId = win.id;
  state.tabId = win.tabs && win.tabs[0] && win.tabs[0].id;
  if (!state.tabId) throw new Error('タブを作成できませんでした');
  // 開いた後 に minimize
  try { await chrome.windows.update(win.id, { state: 'minimized' }); } catch (_) {}

  try {
    // タブ完了待ち
    await waitForTabComplete(state.tabId, /\/maps\/search\//, 30000);
    await ensureContentInjected(state.tabId);
    await updateProgress('serp_scroll', 0, maxScrolls, 'SERP クロール中');

    // SERP 収集
    const serpRes = await sendToTab(
      state.tabId,
      { type: 'SERP_COLLECT', maxScrolls, waitMs },
      120_000,
    );
    if (!serpRes || !serpRes.ok) throw new Error(serpRes && serpRes.error || 'SERP収集失敗');
    const basicRows = serpRes.rows || [];
    state.rows = basicRows.map((r) => ({ ...r, phone: '', website: '', instagramUrl: '', lineUrl: '', hasInstagram: false, hasLineOfficial: false, addressFull: '', photos: [], detailChecked: false }));
    await updateProgress('serp_done', basicRows.length, basicRows.length, `SERP 収集 ${basicRows.length} 件`);

    // 詳細抽出: deepCheck=true の 時 のみ 各 place URL を navigate
    const total = state.rows.length;
    if (deepCheck) {
      for (let i = 0; i < total; i++) {
        if (!state.running) break;
        const row = state.rows[i];
        if (!row.mapsUrl) continue;
        await updateProgress('detail', i + 1, total, `詳細確認: ${row.name}`);
        try {
          await chrome.tabs.update(state.tabId, { url: row.mapsUrl });
          await waitForTabComplete(state.tabId, /\/maps\/place\//, 20000);
          await ensureContentInjected(state.tabId);
          const dres = await sendToTab(state.tabId, { type: 'PLACE_EXTRACT', name: row.name }, 20000);
          if (dres && dres.ok && dres.detail) {
            Object.assign(row, dres.detail, { detailChecked: true });
          }
        } catch (e) {
          row.detailError = String(e.message || e);
        }
        // ちょい間隔 (レート)
        await new Promise((r) => setTimeout(r, 600));
      }
    } else {
      // 速さ優先 モード: SERP のみ、 電話 / HP / SNS は 空欄
      await updateProgress('skip_detail', total, total, '速さ優先モード · 詳細取得スキップ');
    }
    await updateProgress('done', total, total, '完了');
  } catch (e) {
    state.lastError = String(e.message || e);
    await updateProgress('error', 0, 0, state.lastError);
    throw e;
  } finally {
    await closeWindow();
    state.running = false;
    await broadcastProgress();
    // 完了 通知
    try {
      chrome.action.setBadgeText({ text: state.rows.length ? String(state.rows.length) : '' });
    } catch (_) {}
  }
  return state.rows;
}

async function stopJob() {
  state.running = false;
  await closeWindow();
  await updateProgress('stopped', 0, 0, '停止しました');
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === 'BG_START') {
        // license check → deny if not allowed
        const lic = await self.MapsLeadsLicense.checkAndConsume();
        if (!lic.allowed) {
          sendResponse({ ok: false, error: 'license_denied', reason: lic.reason, needKey: !!lic.needKey });
          return;
        }
        // fire-and-forget: popup が閉じても走り続ける
        runJob(msg.payload).then(
          (rows) => chrome.storage.local.set({ ml_last_result: { rows, query: state.query, filters: state.filters, at: Date.now() } }),
          (e) => chrome.storage.local.set({ ml_last_error: { message: String(e.message || e), at: Date.now() } }),
        );
        sendResponse({ ok: true, started: true, license: lic });
        return;
      }
      if (msg.type === 'LICENSE_STATUS') {
        const st = await self.MapsLeadsLicense.status();
        sendResponse({ ok: true, status: st });
        return;
      }
      if (msg.type === 'LICENSE_REGISTER') {
        const res = await self.MapsLeadsLicense.registerLicense(msg.key);
        sendResponse(res);
        return;
      }
      if (msg.type === 'LICENSE_RESET') {
        await self.MapsLeadsLicense.reset();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === 'BG_STATUS') {
        sendResponse({ ok: true, running: state.running, progress: state.progress, rows: state.rows.length });
        return;
      }
      if (msg.type === 'BG_RESULT') {
        sendResponse({ ok: true, rows: state.rows });
        return;
      }
      if (msg.type === 'BG_STOP') {
        await stopJob();
        sendResponse({ ok: true });
        return;
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e.message || e) });
    }
  })();
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: '' });
});

// e2e / debug 用: sw の evaluate 経由で直接叩ける
globalThis.__mapsleads = { runJob, stopJob, state };
