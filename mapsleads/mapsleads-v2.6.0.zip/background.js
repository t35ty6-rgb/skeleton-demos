// MapsLeads v2.6.0 - Places API proxy client (background service worker)
// v2.6.0: 60 件 の 壁 を 撤廃。 エリア を 矩形 に 分割 し locationRestriction で 厳密 に 舐める。
// 埋まった マス は 4 分割 して 掘り下げ、 検索 回数 は 件数 に 応じた budget で 頭打ち。
importScripts('config.js', 'license.js');

const state = {
  running: false,
  rows: [],
  filters: null,
  query: '',
  mode: 'area', // 'area' | 'storeName'
  progress: { phase: 'idle', current: 0, total: 0, msg: '' },
  lastError: null,
  quota: null,
  searchCalls: 0
};

function reset() {
  state.running = false;
  state.rows = [];
  state.progress = { phase: 'idle', current: 0, total: 0, msg: '' };
  state.lastError = null;
  state.searchCalls = 0;
}

async function broadcastProgress() {
  try {
    await chrome.runtime.sendMessage({ type: 'BG_PROGRESS', progress: state.progress, count: state.rows.length, quota: state.quota });
  } catch (_) {}
  const t = state.progress;
  const badge = t.phase === 'idle' ? '' : `${t.current}/${t.total || '?'}`.slice(0, 6);
  try { chrome.action.setBadgeText({ text: badge }); } catch (_) {}
  try { chrome.action.setBadgeBackgroundColor({ color: '#0F1B2D' }); } catch (_) {}
}

async function updateProgress(phase, current, total, msg) {
  state.progress = { phase, current, total, msg: msg || '' };
  await broadcastProgress();
}

async function callProxy(endpointName, body, licenseKey) {
  const url = self.MAPSLEADS_API.BASE + self.MAPSLEADS_API.ENDPOINTS[endpointName];
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-License-Key': licenseKey || ''
    },
    body: JSON.stringify(body || {})
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch (_) { data = { rawBody: text }; }
  return { status: res.status, data, ok: res.ok };
}

async function searchAllPages({ textQuery, includedType, maxResults, licenseKey, locationBias, locationRestriction, maxPages, onCall }) {
  const collected = [];
  let pageToken = null;
  let lastQuota = null;
  const pages = maxPages || 3;

  for (let page = 0; page < pages && collected.length < maxResults; page++) {
    const body = { textQuery, pageSize: 20 };
    if (includedType) body.includedType = includedType;
    if (pageToken) body.pageToken = pageToken;
    if (locationRestriction) body.locationRestriction = locationRestriction;
    else if (locationBias) body.locationBias = locationBias;

    if (onCall) onCall();
    const res = await callProxy('searchStores', body, licenseKey);
    if (!res.ok) {
      const err = new Error(res.data?.message || 'searchStores 失敗');
      err.code = res.data?.code || 'SEARCH_FAIL';
      err.status = res.status;
      err.detail = res.data;
      throw err;
    }

    const places = res.data.places || [];
    for (const p of places) {
      if (collected.length >= maxResults) break;
      collected.push(p);
    }

    lastQuota = res.data.quota || lastQuota;
    pageToken = res.data.nextPageToken;
    if (!pageToken) break;

    await new Promise((r) => setTimeout(r, 1500));
  }

  return { places: collected, quota: lastQuota };
}

// ==== 60 件 の 壁 を 超える 広域 スキャン ====
// Google の text search は 1 クエリ 最大 60 件 (20 件 × 3 ページ)。
// 1 回目 の 結果 の 座標 から 範囲 を 割り出し、 矩形 に 切って locationRestriction で
// 1 マス ずつ 厳密 に 舐める。 60 件 埋まった マス は さらに 4 分割 して 掘り下げる。
// backend が 古くて locationRestriction を 受けない 場合 は locationBias (円) に 自動 で 落とす。
function bboxOfPlaces(places) {
  const pts = places
    .map((p) => p.location)
    .filter((l) => l && typeof l.latitude === 'number' && typeof l.longitude === 'number');
  if (pts.length === 0) return null;
  let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
  for (const l of pts) {
    if (l.latitude < minLat) minLat = l.latitude;
    if (l.latitude > maxLat) maxLat = l.latitude;
    if (l.longitude < minLng) minLng = l.longitude;
    if (l.longitude > maxLng) maxLng = l.longitude;
  }
  return { minLat, maxLat, minLng, maxLng };
}

function padBox(b) {
  const spanLat = Math.max(b.maxLat - b.minLat, 0.02);
  const spanLng = Math.max(b.maxLng - b.minLng, 0.02);
  return {
    minLat: Math.max(-89.9, b.minLat - spanLat * 0.15),
    maxLat: Math.min(89.9, b.maxLat + spanLat * 0.15),
    minLng: b.minLng - spanLng * 0.15,
    maxLng: b.maxLng + spanLng * 0.15
  };
}

function splitBox(b, n) {
  const dLat = (b.maxLat - b.minLat) / n;
  const dLng = (b.maxLng - b.minLng) / n;
  const cLat = (b.minLat + b.maxLat) / 2;
  const cLng = (b.minLng + b.maxLng) / 2;
  const out = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      out.push({
        minLat: b.minLat + dLat * i,
        maxLat: b.minLat + dLat * (i + 1),
        minLng: b.minLng + dLng * j,
        maxLng: b.minLng + dLng * (j + 1)
      });
    }
  }
  // 中心 に 近い マス から (店 が 濃い ので 早く 貯まる)
  out.sort((x, y) => {
    const dx = ((x.minLat + x.maxLat) / 2 - cLat) ** 2 + ((x.minLng + x.maxLng) / 2 - cLng) ** 2;
    const dy = ((y.minLat + y.maxLat) / 2 - cLat) ** 2 + ((y.minLng + y.maxLng) / 2 - cLng) ** 2;
    return dx - dy;
  });
  return out;
}

function boxToRestriction(b) {
  return {
    rectangle: {
      low: { latitude: b.minLat, longitude: b.minLng },
      high: { latitude: b.maxLat, longitude: b.maxLng }
    }
  };
}

function boxToBias(b) {
  const lat = (b.minLat + b.maxLat) / 2;
  const lng = (b.minLng + b.maxLng) / 2;
  const mLat = (b.maxLat - b.minLat) * 111320;
  const mLng = (b.maxLng - b.minLng) * 111320 * Math.cos((lat * Math.PI) / 180);
  const radius = Math.min(50000, Math.max(400, (Math.sqrt(mLat * mLat + mLng * mLng) / 2) * 1.1));
  return { circle: { center: { latitude: lat, longitude: lng }, radius } };
}

// 取得 件数 から 検索 API の 呼び出し 上限 を 決める (使用量 の 暴走 防止)
function callBudgetFor(maxResults) {
  if (maxResults <= 60) return 3;
  return Math.min(120, Math.ceil(maxResults / 20) * 4);
}

async function searchWide({ textQuery, maxResults, licenseKey }) {
  const seen = new Map();
  let quota = null;
  let calls = 0;
  const budget = callBudgetFor(maxResults);
  let useRestriction = true;
  const onCall = () => { calls++; };
  const push = (arr) => {
    for (const p of arr || []) {
      if (p && p.id && !seen.has(p.id)) seen.set(p.id, p);
    }
  };

  // 1st pass: 普通 の text search (最大 60 件)
  const first = await searchAllPages({
    textQuery,
    maxResults: Math.min(maxResults, 60),
    licenseKey,
    maxPages: 3,
    onCall
  });
  push(first.places);
  if (first.quota) quota = first.quota;
  await updateProgress('searching', seen.size, maxResults, `${seen.size} 件 取得`);

  if (seen.size >= maxResults) {
    return { places: Array.from(seen.values()).slice(0, maxResults), quota, calls };
  }

  const base = bboxOfPlaces(Array.from(seen.values()));
  if (!base) return { places: Array.from(seen.values()), quota, calls };

  // 2nd pass: 矩形 を 幅優先 で 舐める。 埋まった マス は 4 分割 して 掘る。
  const n0 = maxResults <= 120 ? 3 : (maxResults <= 250 ? 4 : 5);
  const queue = splitBox(padBox(base), n0).map((b) => ({ box: b, depth: 0 }));

  let emptyStreak = 0;
  while (queue.length > 0) {
    if (!state.running) break;
    if (seen.size >= maxResults) break;
    if (calls >= budget) break;

    const { box, depth } = queue.shift();
    const before = seen.size;
    let r = null;

    try {
      r = await searchAllPages({
        textQuery,
        maxResults: 60,
        licenseKey,
        maxPages: 3,
        onCall,
        ...(useRestriction
          ? { locationRestriction: boxToRestriction(box) }
          : { locationBias: boxToBias(box) })
      });
    } catch (e) {
      if (e.code === 'MONTHLY_CAP_EXCEEDED' || e.code === 'REVOKED' || e.code === 'INVALID_KEY') throw e;
      // backend が locationRestriction 未対応 (未 deploy) なら 円 bias に 落として やり直す
      if (useRestriction && (e.status === 400 || e.status === 502)) {
        useRestriction = false;
        queue.unshift({ box, depth });
        continue;
      }
      continue;
    }

    push(r.places);
    if (r.quota) quota = r.quota;
    const added = seen.size - before;
    await updateProgress(
      'searching',
      seen.size,
      maxResults,
      `広域 スキャン ${seen.size} 件 (残り ${queue.length} マス)`
    );

    // マス が 埋まって いる = まだ 取り切れて いない ので 細かく 割る
    if (useRestriction && r.places.length >= 55 && depth < 2 && seen.size < maxResults) {
      splitBox(box, 2).forEach((b) => queue.push({ box: b, depth: depth + 1 }));
    }

    if (added === 0) {
      emptyStreak++;
      if (emptyStreak >= 8) break;
    } else {
      emptyStreak = 0;
    }
    await new Promise((r2) => setTimeout(r2, 350));
  }

  return { places: Array.from(seen.values()).slice(0, maxResults), quota, calls };
}

async function enrichSocialForPlace(place, licenseKey) {
  if (!place.website) return { instagramUrl: '', lineUrl: '' };

  // 予約 サイト しか 無い 場合 は 自社 HP じゃ ないので socil scrape の 対象 外
  if (place.websiteIsBookingOnly) return { instagramUrl: '', lineUrl: '' };

  try {
    const res = await callProxy('enrichSocial', { websiteUrl: place.website }, licenseKey);
    if (!res.ok) return { instagramUrl: '', lineUrl: '' };
    return {
      instagramUrl: res.data.instagramUrl || '',
      lineUrl: res.data.lineUrl || ''
    };
  } catch (_) {
    return { instagramUrl: '', lineUrl: '' };
  }
}

function toRow(place, social) {
  return {
    name: place.name,
    category: place.category,
    rating: place.rating != null ? place.rating : '',
    reviewCount: place.userRatingCount || '',
    phone: place.phone,
    addressFull: place.address,
    area: '',
    hours: '',
    website: place.website,
    hasOwnWebsite: !!(place.website && !place.websiteIsBookingOnly),
    websiteIsBookingOnly: place.websiteIsBookingOnly,
    instagramUrl: social?.instagramUrl || '',
    lineUrl: social?.lineUrl || '',
    hasInstagram: !!(social?.instagramUrl),
    hasLineOfficial: !!(social?.lineUrl),
    mapsUrl: place.mapsUrl,
    placeId: place.id,
    photoNames: Array.isArray(place.photoNames) ? place.photoNames : [],
    photoCount: place.photoCount || 0,
    photos: [],
    types: place.types || []
  };
}

async function runJob({ mode, storeName, area, category, maxResults, enrichSocial, licenseKey }) {
  if (state.running) throw new Error('すでに実行中');
  reset();
  state.running = true;
  state.mode = mode || 'area';
  state.query = mode === 'storeName' ? storeName : [area, category].filter(Boolean).join(' ');

  await updateProgress('starting', 0, 0, '検索 準備 中');

  const textQuery = state.query;
  if (!textQuery) throw new Error('検索 クエリ が 空 です');

  try {
    const cap = Math.min(500, Math.max(1, maxResults || 20));

    await updateProgress('searching', 0, cap, '公式 サービス 呼び出し 中');
    const { places, quota, calls } = await searchWide({
      textQuery,
      maxResults: cap,
      licenseKey
    });

    state.quota = quota;
    state.searchCalls = calls || 0;
    await updateProgress('search_done', places.length, places.length, `${places.length} 件 発見`);

    // 基本 行 を まず 作成
    state.rows = places.map((p) => toRow(p, null));

    // enrichSocial: 各 店舗 の HP を 読み込み Insta/LINE 拾う
    if (enrichSocial) {
      for (let i = 0; i < state.rows.length; i++) {
        if (!state.running) break;
        const row = state.rows[i];
        await updateProgress('enrich', i + 1, state.rows.length, `SNS 確認: ${row.name}`);
        if (row.website && !row.websiteIsBookingOnly) {
          const social = await enrichSocialForPlace(places[i], licenseKey);
          row.instagramUrl = social.instagramUrl;
          row.lineUrl = social.lineUrl;
          row.hasInstagram = !!social.instagramUrl;
          row.hasLineOfficial = !!social.lineUrl;
        }
        await new Promise((r) => setTimeout(r, 300));
      }
    } else {
      await updateProgress('skip_enrich', state.rows.length, state.rows.length, 'SNS 補完 スキップ');
    }

    await updateProgress('done', state.rows.length, state.rows.length, `完了 · ${state.rows.length} 件 (検索 ${state.searchCalls} 回)`);
  } catch (e) {
    state.lastError = String(e.message || e);
    if (e.code === 'MONTHLY_CAP_EXCEEDED') {
      await updateProgress('cap_exceeded', 0, 0, state.lastError);
    } else if (e.code === 'REVOKED' || e.code === 'INVALID_KEY') {
      await updateProgress('license_error', 0, 0, state.lastError);
    } else {
      await updateProgress('error', 0, 0, state.lastError);
    }
    throw e;
  } finally {
    state.running = false;
    await broadcastProgress();
    try {
      chrome.action.setBadgeText({ text: state.rows.length ? String(state.rows.length) : '' });
    } catch (_) {}
  }

  return state.rows;
}

async function stopJob() {
  state.running = false;
  await updateProgress('stopped', 0, 0, '停止しました');
}

async function fetchPhotoUrl(photoName, licenseKey, maxWidthPx) {
  const res = await callProxy('getPhoto', { photoName, maxWidthPx: maxWidthPx || 1600 }, licenseKey);
  if (!res.ok) return null;
  return res.data.photoUri || null;
}

async function verifyLicenseServer(licenseKey) {
  try {
    const res = await callProxy('verifyLicense', {}, licenseKey);
    return res.data;
  } catch (_) {
    return { valid: false, code: 'NETWORK_ERROR' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === 'BG_START') {
        const localLic = await self.MapsLeadsLicense.checkAndConsume();
        if (!localLic.allowed) {
          sendResponse({ ok: false, error: 'license_denied', reason: localLic.reason, needKey: !!localLic.needKey });
          return;
        }

        const licenseKey = await self.MapsLeadsLicense.getKey();
        if (!licenseKey) {
          // v2.0.0 は API 前提 なので trial mode 廃止。 キー 必須。
          sendResponse({ ok: false, error: 'license_denied', reason: 'trial_exhausted', needKey: true });
          return;
        }

        runJob({ ...msg.payload, licenseKey }).then(
          (rows) => chrome.storage.local.set({
            ml_last_result: {
              rows,
              query: state.query,
              mode: state.mode,
              filters: state.filters,
              quota: state.quota,
              at: Date.now()
            }
          }),
          (e) => chrome.storage.local.set({
            ml_last_error: {
              message: String(e.message || e),
              code: e.code || 'ERR',
              at: Date.now()
            }
          })
        );
        sendResponse({ ok: true, started: true });
        return;
      }
      if (msg.type === 'LICENSE_STATUS') {
        const st = await self.MapsLeadsLicense.status();
        sendResponse({ ok: true, status: st });
        return;
      }
      if (msg.type === 'LICENSE_VERIFY_SERVER') {
        const key = await self.MapsLeadsLicense.getKey();
        if (!key) { sendResponse({ ok: false, error: 'no_key' }); return; }
        const st = await verifyLicenseServer(key);
        sendResponse({ ok: true, status: st });
        return;
      }
      if (msg.type === 'LICENSE_REGISTER') {
        const res = await self.MapsLeadsLicense.registerLicense(msg.key);
        sendResponse(res);
        return;
      }
      if (msg.type === 'LICENSE_RESET') {
        await self.MapsLeadsLicense.reset();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === 'BG_ESTIMATE') {
        sendResponse({ ok: true, budget: callBudgetFor(Math.min(500, Math.max(1, msg.maxResults || 40))) });
        return;
      }
      if (msg.type === 'BG_STATUS') {
        sendResponse({
          ok: true,
          running: state.running,
          progress: state.progress,
          rows: state.rows.length,
          quota: state.quota,
          searchCalls: state.searchCalls
        });
        return;
      }
      if (msg.type === 'BG_RESULT') {
        sendResponse({ ok: true, rows: state.rows, quota: state.quota, searchCalls: state.searchCalls });
        return;
      }
      if (msg.type === 'BG_STOP') {
        await stopJob();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === 'GET_PHOTO') {
        const key = await self.MapsLeadsLicense.getKey();
        const uri = await fetchPhotoUrl(msg.photoName, key, msg.maxWidthPx);
        sendResponse({ ok: !!uri, photoUri: uri });
        return;
      }
      if (msg.type === 'GENERATE_COPY') {
        const key = await self.MapsLeadsLicense.getKey();
        if (!key) { sendResponse({ ok: false, error: 'no_license' }); return; }
        const { ml_philosophy } = await chrome.storage.local.get('ml_philosophy');
        const philosophy = (ml_philosophy && ml_philosophy.text) || '';
        if (!philosophy.trim() || philosophy.trim().length < 20) {
          sendResponse({ ok: false, error: 'no_philosophy', skip: true });
          return;
        }
        const payload = { philosophy, store: msg.store };
        if (msg.perStoreContext && String(msg.perStoreContext).trim().length > 0) {
          payload.perStoreContext = String(msg.perStoreContext).trim();
        }
        const res = await callProxy('generateCopy', payload, key);
        if (!res.ok) {
          sendResponse({ ok: false, error: res.data?.code || res.data?.error || 'generate_failed' });
          return;
        }
        sendResponse({ ok: true, copy: res.data.copy, quota: res.data.quota, usage: res.data.usage });
        return;
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e.message || e) });
    }
  })();
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: '' });
});

globalThis.__mapsleads = { runJob, stopJob, state };
