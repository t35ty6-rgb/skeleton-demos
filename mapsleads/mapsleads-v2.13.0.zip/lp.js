// MapsLeads · LP 型 (Style I) 専用 レンダラー  v2.13.0
//
// いろは整体スクール / サロンワークスLP と 同じ 構成 を、 店舗 提案 用 に 組み直した もの。
// 既存 の renderMockHP は 「情報 を 並べる 会社 案内」 型。 こちら は 「読ませて 動かす」 LP 型。
//   hero(3枚組 + 事実バッジ) → 悩み → 強み3本(特大番号) → メニュー(リボン)
//   → 来店の流れ → アクセス → FAQ → 締めCTA(電話/LINE)

// ---- 業種 別 の 定型 (AI が 書か ない 部分 を 埋める) ----
const LP_TRADE = {
  salon: {
    trio: ['カウンセリング', 'カットとカラー', '仕上げとご提案'],
    trioCap: '相談してから切る。だから、仕上がりがぶれません。',
    worries: ['いつも「おまかせ」になってしまう', '朝のセットに時間がかかる', '白髪が気になりはじめた'],
    flow: [['ご予約', 'お電話かLINEで。希望の時間をお伝えください。'],
           ['カウンセリング', '髪の状態と、普段のお手入れを伺います。'],
           ['施術', '座り心地を確かめながら進めます。'],
           ['仕上げとご説明', 'ご自宅での手入れ方法をお伝えします。']],
    faq: [['初めてでも大丈夫ですか。', 'はい。カウンセリングの時間を長めに取ります。'],
          ['どれくらい時間がかかりますか。', 'メニューによりますが、カットで約1時間です。'],
          ['駐車場はありますか。', 'お停めいただけます。詳しくはお問い合わせください。']]
  },
  cafe: {
    trio: ['豆を選ぶ', '一杯ずつ淹れる', '席でゆっくり'],
    trioCap: '急がずに、一杯ずつ。',
    worries: ['落ち着いて作業できる店が近くにない', 'одно — 使わない', 'ひとりで入りやすい店を探している'],
    flow: [['ご来店', '予約は不要です。'], ['ご注文', 'カウンターでお選びください。'],
           ['お席へ', 'お好きな席でお待ちください。'], ['おかわり', '二杯目は割引しています。']],
    faq: [['予約はできますか。', '基本は不要です。人数が多い場合はご相談ください。'],
          ['電源とWi-Fiはありますか。', 'ご用意しています。'],
          ['駐車場はありますか。', 'お停めいただけます。']]
  },
  generic: {
    trio: ['まずお話を伺う', '手を動かす', '仕上げてお渡し'],
    trioCap: '聞いてから、手を動かします。',
    worries: ['どこに頼めばいいか分からない', '相談だけでも大丈夫か不安', '急ぎで対応してほしい'],
    flow: [['お問い合わせ', 'お電話かLINEでご連絡ください。'],
           ['ご相談', 'ご希望とご予算を伺います。'],
           ['対応', '内容を確認しながら進めます。'],
           ['お引き渡し', '仕上がりをご確認いただきます。']],
    faq: [['初めてでも大丈夫ですか。', 'はい。分かりやすくご説明します。'],
          ['相談だけでもいいですか。', 'もちろんです。お気軽にどうぞ。'],
          ['駐車場はありますか。', 'お停めいただけます。']]
  }
};

function lpTrade(trade) {
  const t = LP_TRADE[trade];
  if (!t) return LP_TRADE.generic;
  return {
    trio: t.trio, trioCap: t.trioCap,
    worries: t.worries.filter((w) => !w.includes('使わない')),
    flow: t.flow, faq: t.faq
  };
}

// ---- 本体 ----
function renderLpHP(row, aiCopy, ctx) {
  const e = ctx.escapeHtml, a = ctx.escapeAttr;
  const u = ctx.cssUrl || a; // CSS の url() 用 escape
  const name = row.name || '店舗名';
  const cat = row.category || '';
  const phone = row.phone || '';
  const address = row.addressFull || '';
  const t = lpTrade(ctx.trade);

  const catch_ = (aiCopy && aiCopy.hero_catchcopy) || ctx.templateHero.h1plain || 'この街で、長く通える店に。';
  const sub = (aiCopy && aiCopy.hero_sub) || ctx.templateHero.sub || '';
  const aboutH = (aiCopy && aiCopy.about && aiCopy.about.heading) || 'ここで大切にしていること';
  const aboutB = (aiCopy && aiCopy.about && aiCopy.about.body) || '';
  const svcs = ctx.services;
  const imgs = ctx.images;

  const tel = phone
    ? `<a class="lp-btn" href="tel:${a(phone)}">${e(phone)} に電話<span aria-hidden="true">→</span></a>`
    : `<a class="lp-btn" href="#lp-contact">お問い合わせ<span aria-hidden="true">→</span></a>`;

  // 事実バッジ: 数字 訴求 は 使わ ない (口コミ 件数 · 評価 は 出さ ない)
  const facts = [
    { lbl: '業種', main: e(cat || 'お店') },
    { lbl: 'エリア', main: e((address.match(/(.{2,3}[都道府県].{1,6}[市区町村])/) || [, address.slice(0, 8)])[1] || '') },
    { lbl: 'ご予約', main: phone ? 'お電話で' : 'お問い合わせ' }
  ];

  const trioPhotos = imgs.gallery.length >= 3 ? imgs.gallery.slice(0, 3) : null;

  return `
  <div class="lp" data-lp="1">

    <header class="lp-top">
      <div class="lp-wrap lp-top-in">
        <div class="lp-logo">${e(name)}<small>${e(cat)}</small></div>
        ${phone ? `<a class="lp-btn lp-btn--sm" href="tel:${a(phone)}">${e(phone)}</a>` : ''}
      </div>
    </header>

    <section class="lp-hero">
      <div class="lp-wrap">
        <p class="lp-eyebrow"><span>${e(cat || 'お店')}</span><span>${e(name)}</span></p>
        <h1 class="lp-h1 ml-edit" data-field="hero_catchcopy" contenteditable="true" spellcheck="false">${e(catch_)}</h1>
        <p class="lp-lead ml-edit" data-field="hero_sub" contenteditable="true" spellcheck="false">${e(sub)}</p>

        ${trioPhotos ? `
        <figure class="lp-trio">
          ${trioPhotos.map((src, i) => `
            <div class="lp-trio-p">
              <img src="${a(src)}" alt="">
              <span class="lp-trio-no">${i + 1}</span>
              <span class="lp-trio-bb">${e(t.trio[i] || '')}</span>
            </div>`).join('')}
          <figcaption>${e(t.trioCap)}</figcaption>
        </figure>` : `
        <div class="lp-hero-art" style="background-image:url('${u(imgs.hero)}')"></div>`}

        <div class="lp-cta-row">${tel}<a class="lp-link" href="#lp-menu">できることを見る</a></div>

        <ul class="lp-ems">
          ${facts.map((f) => `<li><p class="lp-em-lbl">${f.lbl}</p><p class="lp-em-main">${f.main}</p></li>`).join('')}
        </ul>
      </div>
    </section>

    <section class="lp-worry">
      <div class="lp-wrap">
        <h2 class="lp-worry-title">こんなこと、ありませんか？</h2>
        <ul class="lp-bubbles">
          ${t.worries.map((w) => `<li>${e(w)}</li>`).join('')}
        </ul>
      </div>
    </section>

    <section class="lp-sec lp-sec--white" id="lp-about">
      <div class="lp-wrap">
        <div class="lp-head">
          <p class="lp-no"><span>01</span>CONCEPT</p>
          <h2 class="lp-h2 ml-edit" data-field="about_heading" contenteditable="true" spellcheck="false">${e(aboutH)}</h2>
        </div>
        <div class="lp-about">
          <div class="lp-about-fig" style="background-image:url('${u(imgs.about)}')"></div>
          <div class="lp-about-body">
            <p class="ml-edit" data-field="about_body" contenteditable="true" spellcheck="false">${e(aboutB)}</p>
          </div>
        </div>
      </div>
    </section>

    <section class="lp-sec lp-sec--mint" id="lp-menu">
      <div class="lp-wrap">
        <div class="lp-head">
          <p class="lp-no"><span>02</span>MENU</p>
          <h2 class="lp-h2">できること</h2>
        </div>
        <div class="lp-menu">
          ${svcs.slice(0, 4).map((s, i) => `
            <article class="lp-card${i === 0 ? ' lp-card--main' : ''}">
              ${i === 0 ? '<span class="lp-ribbon">まずはこちら</span>' : ''}
              <h3 class="ml-edit" data-field="svc_name_${i}" contenteditable="true" spellcheck="false">${e(s.name)}</h3>
              <p class="ml-edit" data-field="svc_desc_${i}" contenteditable="true" spellcheck="false">${e(s.desc)}</p>
              <p class="lp-price">${e(s.price)}</p>
            </article>`).join('')}
        </div>
      </div>
    </section>

    <section class="lp-sec lp-sec--white">
      <div class="lp-wrap">
        <div class="lp-head">
          <p class="lp-no"><span>03</span>FLOW</p>
          <h2 class="lp-h2">ご来店の流れ</h2>
        </div>
        <ol class="lp-flow">
          ${t.flow.map(([h, b], i) => `
            <li><span class="lp-flow-no">${i + 1}</span><div><h4>${e(h)}</h4><p>${e(b)}</p></div></li>`).join('')}
        </ol>
      </div>
    </section>

    <section class="lp-sec lp-sec--mint">
      <div class="lp-wrap">
        <div class="lp-head">
          <p class="lp-no"><span>04</span>ACCESS</p>
          <h2 class="lp-h2">場所とご連絡先</h2>
        </div>
        <dl class="lp-access">
          ${address ? `<div><dt>住所</dt><dd>${e(address)}</dd></div>` : ''}
          ${phone ? `<div><dt>お電話</dt><dd><a href="tel:${a(phone)}">${e(phone)}</a></dd></div>` : ''}
          ${row.hours ? `<div><dt>営業時間</dt><dd>${e(row.hours)}</dd></div>` : ''}
          ${row.lineUrl ? `<div><dt>LINE</dt><dd><a href="${a(row.lineUrl)}">友だち追加</a></dd></div>` : ''}
        </dl>
      </div>
    </section>

    <section class="lp-sec lp-sec--white">
      <div class="lp-wrap">
        <div class="lp-head">
          <p class="lp-no"><span>05</span>FAQ</p>
          <h2 class="lp-h2">よくあるご質問</h2>
        </div>
        <div class="lp-qa">
          ${t.faq.map(([q, ans]) => `
            <details><summary><i>Q</i>${e(q)}</summary><p><i>A</i>${e(ans)}</p></details>`).join('')}
        </div>
      </div>
    </section>

    <section class="lp-contact" id="lp-contact">
      <div class="lp-wrap">
        <p class="lp-contact-kicker">まずは、お気軽に。</p>
        <h2 class="lp-contact-h">${e(name)}</h2>
        <div class="lp-contact-cards">
          ${phone ? `<a class="lp-cc" href="tel:${a(phone)}"><span>お電話</span><b>${e(phone)}</b></a>` : ''}
          ${row.lineUrl ? `<a class="lp-cc lp-cc--line" href="${a(row.lineUrl)}"><span>LINE</span><b>友だち追加</b></a>` : ''}
          ${row.mapsUrl ? `<a class="lp-cc" href="${a(row.mapsUrl)}"><span>地図</span><b>道順を見る</b></a>` : ''}
        </div>
      </div>
    </section>

    <footer class="lp-foot">
      <div class="lp-wrap">
        <p class="lp-foot-brand">${e(name)}</p>
        <p class="lp-foot-copy">${e(address)}</p>
      </div>
    </footer>
  </div>`;
}

if (typeof self !== 'undefined') {
  self.renderLpHP = renderLpHP;
  self.LP_TRADE = LP_TRADE;
}
