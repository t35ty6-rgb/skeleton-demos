// MapsLeads popup UI (v0.4 background-mode)
const els = {};
[
  'pref', 'city', 'categoryPreset', 'categoryText', 'queryPreview',
  'fNoWeb', 'fInsta', 'fLine',
  'maxScrolls', 'waitMs', 'deepCheck',
  'openMaps', 'start', 'stop', 'reset', 'csv', 'copy',
  'total', 'hit', 'noweb', 'progress', 'msg',
].forEach((id) => { els[id] = document.getElementById(id); });

let currentRows = [];

// ===== プルダウン =====
function buildRegionSelects() {
  Object.keys(window.MAPS_REGIONS).forEach((p) => {
    const o = document.createElement('option'); o.value = p; o.textContent = p;
    els.pref.appendChild(o);
  });
  window.MAPS_CATEGORIES.forEach((c) => {
    const o = document.createElement('option'); o.value = c; o.textContent = c;
    els.categoryPreset.appendChild(o);
  });
  els.pref.addEventListener('change', () => {
    els.city.innerHTML = '<option value="">選択</option>';
    (window.MAPS_REGIONS[els.pref.value] || []).forEach((c) => {
      const o = document.createElement('option'); o.value = c; o.textContent = c;
      els.city.appendChild(o);
    });
    saveState(); updateQuery();
  });
  els.city.addEventListener('change', () => { saveState(); updateQuery(); });
  els.categoryPreset.addEventListener('change', () => {
    if (els.categoryPreset.value) els.categoryText.value = els.categoryPreset.value;
    saveState(); updateQuery();
  });
  els.categoryText.addEventListener('input', () => { saveState(); updateQuery(); });
}
function currentQuery() {
  const p = els.pref.value || '';
  const c = els.city.value || '';
  const cat = els.categoryText.value || els.categoryPreset.value || '';
  return [p, c, cat].filter(Boolean).join(' ');
}
function updateQuery() {
  const q = currentQuery();
  els.queryPreview.textContent = q ? `検索クエリ: ${q}` : '検索クエリ: -';
}

// ===== state 永続化 =====
function saveState() {
  chrome.storage.local.set({
    ml_state: {
      pref: els.pref.value, city: els.city.value,
      categoryPreset: els.categoryPreset.value, categoryText: els.categoryText.value,
      fNoWeb: els.fNoWeb.checked, fInsta: els.fInsta.checked, fLine: els.fLine.checked,
      maxScrolls: els.maxScrolls.value, waitMs: els.waitMs.value, deepCheck: els.deepCheck.value,
    },
  });
}
async function loadState() {
  const { ml_state } = await chrome.storage.local.get('ml_state');
  if (!ml_state) return;
  els.pref.value = ml_state.pref || '';
  if (els.pref.value) els.pref.dispatchEvent(new Event('change'));
  els.city.value = ml_state.city || '';
  els.categoryPreset.value = ml_state.categoryPreset || '';
  els.categoryText.value = ml_state.categoryText || '';
  els.fNoWeb.checked = ml_state.fNoWeb !== false;
  els.fInsta.checked = !!ml_state.fInsta;
  els.fLine.checked = !!ml_state.fLine;
  if (ml_state.maxScrolls) els.maxScrolls.value = ml_state.maxScrolls;
  if (ml_state.waitMs) els.waitMs.value = ml_state.waitMs;
  if (ml_state.deepCheck) els.deepCheck.value = ml_state.deepCheck;
  updateQuery();
}

// ===== License =====
const TRIAL_LIMIT = 5;
async function getLicenseState() {
  const { ml_license, ml_trial_used } = await chrome.storage.local.get(['ml_license', 'ml_trial_used']);
  return { license: ml_license || null, trialUsed: ml_trial_used || 0 };
}
function isLicenseValid(key) {
  if (!key || typeof key !== 'string') return false;
  const m = key.trim().match(/^ML-([A-Z0-9]{12})$/);
  if (!m) return false;
  const body = m[1];
  let sum = 0;
  for (const c of body) sum += c.charCodeAt(0);
  return sum % 9 === 0;
}
async function incrementTrialUsed() {
  const { ml_trial_used } = await chrome.storage.local.get('ml_trial_used');
  const next = (ml_trial_used || 0) + 1;
  await chrome.storage.local.set({ ml_trial_used: next });
  return next;
}
async function promptForLicense() {
  const key = prompt(
    `無料トライアルは ${TRIAL_LIMIT} 検索まで。\n\n継続利用にはライセンスキー が必要です。\n購入: https://skeleton-inc.jp/mapsleads\n\nキーをお持ちの方は入力:`
  );
  if (!key) return false;
  if (!isLicenseValid(key.trim())) { alert('ライセンスキーが無効です。'); return false; }
  await chrome.storage.local.set({ ml_license: key.trim() });
  return true;
}

// ===== UI =====
function setMsg(text, err = false) {
  els.msg.textContent = text;
  els.msg.classList.toggle('err', !!err);
}
function passFilters(r) {
  // 「HP無し」 は 自社 HP 無し = website 未登録 OR 予約サイト のみ
  if (els.fNoWeb.checked && r.hasOwnWebsite) return false;
  if (els.fInsta.checked && !r.hasInstagram) return false;
  if (els.fLine.checked && !r.hasLineOfficial) return false;
  return true;
}
function renderStat(rows) {
  els.total.textContent = rows.length;
  els.hit.textContent = rows.filter(passFilters).length;
  els.noweb.textContent = rows.filter((r) => !r.website).length;
  const anyHit = rows.filter(passFilters).length > 0;
  els.csv.disabled = !anyHit;
  els.copy.disabled = !anyHit;
}

// ===== 出力 =====
const COLS = ['name', 'category', 'rating', 'reviewCount', 'phone', 'addressFull', 'area', 'hours', 'website', 'hasOwnWebsite', 'websiteIsBookingOnly', 'instagramUrl', 'lineUrl', 'hasInstagram', 'hasLineOfficial', 'mapsUrl'];
const HEAD = ['店名', '業種', '評価', 'レビュー数', '電話', '住所', 'エリア', '営業状態', 'ウェブサイト', '自社HP有', '予約サイトのみ', 'Instagram URL', 'LINE URL', 'Insta有', '公式LINE有', 'Maps URL'];
function toCSV(rows) {
  const esc = (v) => { const s = String(v == null ? '' : (typeof v === 'boolean' ? (v ? '○' : '') : v)); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return '﻿' + [HEAD.join(','), ...rows.map((r) => COLS.map((c) => esc(r[c])).join(','))].join('\r\n');
}
function toTSV(rows) {
  const clean = (v) => String(v == null ? '' : (typeof v === 'boolean' ? (v ? '○' : '') : v)).replace(/\t/g, ' ').replace(/\r?\n/g, ' ');
  return [HEAD.join('\t'), ...rows.map((r) => COLS.map((c) => clean(r[c])).join('\t'))].join('\n');
}

// ===== background 通信 =====
function bg(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(res);
    });
  });
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'BG_PROGRESS') {
    const p = msg.progress || {};
    let s = '';
    if (p.phase === 'starting') s = '起動中…';
    else if (p.phase === 'serp_scroll') s = `[1/2] SERP スクロール ${p.current}/${p.total || '?'}`;
    else if (p.phase === 'serp_done') s = `SERP 収集 ${p.total}件 → 詳細確認へ`;
    else if (p.phase === 'detail') s = `[2/2] 詳細確認 ${p.current}/${p.total}: ${p.msg || ''}`;
    else if (p.phase === 'done') s = `完了 ${p.total}件`;
    else if (p.phase === 'stopped') s = '停止';
    else if (p.phase === 'error') s = `エラー: ${p.msg}`;
    else if (p.phase === 'idle') s = '-';
    else s = JSON.stringify(p);
    els.progress.textContent = s;
    // 完了時は 結果 取得
    if (p.phase === 'done' || p.phase === 'stopped') {
      loadResultFromBg().then(() => {});
    }
  }
});

async function loadResultFromBg() {
  try {
    const res = await bg({ type: 'BG_RESULT' });
    if (res && res.ok) {
      currentRows = res.rows || [];
      renderStat(currentRows);
      setMsg(`結果: total ${currentRows.length} 件 / 条件hit ${currentRows.filter(passFilters).length} 件`);
    }
  } catch (_) {}
}

// ===== ハンドラ =====
els.openMaps && els.openMaps.addEventListener('click', async () => {
  const q = currentQuery();
  if (!q) { setMsg('県 · 市 · 業種を選んで', true); return; }
  await chrome.tabs.create({ url: `https://www.google.com/maps/search/${encodeURIComponent(q)}` });
});

els.start.addEventListener('click', async () => {
  setMsg('');
  const q = currentQuery();
  if (!q) { setMsg('県 · 市 · 業種を選んで', true); return; }

  // license gate
  const { license, trialUsed } = await getLicenseState();
  const licensed = isLicenseValid(license);
  if (!licensed && trialUsed >= TRIAL_LIMIT) {
    const got = await promptForLicense();
    if (!got) { setMsg('ライセンス未登録のため実行できません', true); return; }
  }

  els.start.disabled = true;
  els.stop.disabled = false;
  currentRows = [];
  renderStat(currentRows);
  els.progress.textContent = '起動…';

  try {
    const res = await bg({
      type: 'BG_START',
      payload: {
        query: q,
        maxScrolls: parseInt(els.maxScrolls.value, 10) || 40,
        waitMs: parseInt(els.waitMs.value, 10) || 1200,
        filters: {
          fNoWeb: els.fNoWeb.checked, fInsta: els.fInsta.checked, fLine: els.fLine.checked,
        },
      },
    });
    if (!res || !res.ok) throw new Error(res && res.error || '起動失敗');
    if (!licensed) await incrementTrialUsed();
    setMsg('裏で作業中… (popup を 閉じても継続、 完了時 バッジ更新)');
  } catch (e) {
    setMsg(`エラー: ${e.message}`, true);
  } finally {
    els.start.disabled = false;
    els.stop.disabled = true;
  }
});

els.stop.addEventListener('click', async () => {
  try { await bg({ type: 'BG_STOP' }); setMsg('停止しました'); }
  catch (e) { setMsg(`停止失敗: ${e.message}`, true); }
});

els.reset.addEventListener('click', () => {
  currentRows = []; renderStat(currentRows); els.progress.textContent = '-'; setMsg('');
});

[els.fNoWeb, els.fInsta, els.fLine].forEach((el) => {
  el.addEventListener('change', () => { renderStat(currentRows); saveState(); });
});

els.csv.addEventListener('click', async () => {
  const rows = currentRows.filter(passFilters);
  if (!rows.length) { setMsg('該当 0 件', true); return; }
  const csv = toCSV(rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const dt = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const q = currentQuery().replace(/\s+/g, '_');
  try {
    await chrome.downloads.download({ url, filename: `mapsleads-${q || 'result'}-${dt}.csv`, saveAs: true });
    setMsg(`${rows.length} 件 CSV 出力`);
  } catch (e) { setMsg(`DL 失敗: ${e.message}`, true); }
});
els.copy.addEventListener('click', async () => {
  const rows = currentRows.filter(passFilters);
  if (!rows.length) { setMsg('該当 0 件', true); return; }
  try { await navigator.clipboard.writeText(toTSV(rows)); setMsg(`${rows.length} 件 コピー (スプシに貼付可)`); }
  catch (e) { setMsg(`コピー 失敗: ${e.message}`, true); }
});

[els.maxScrolls, els.waitMs, els.deepCheck].forEach((el) => el.addEventListener('change', saveState));

// 起動時: 前回結果を bg から拾う
(async () => {
  buildRegionSelects();
  await loadState();
  updateQuery();
  // popup 再度開いた時、 進捗表示回復
  try {
    const status = await bg({ type: 'BG_STATUS' });
    if (status && status.ok) {
      if (status.running) {
        setMsg('裏で作業中… (完了 まで お待ちを)');
        els.progress.textContent = status.progress ? `${status.progress.phase} ${status.progress.current}/${status.progress.total}` : '進行中';
      } else if (status.rows > 0) {
        await loadResultFromBg();
      }
    }
  } catch (_) {}
})();
