// MapsLeads · あしらい の 引き出し  v2.15.0
//
// 参考 に した LP あしらい の 定番:
//   枠(フレーム) / 角括弧ボックス / リボン見出し / スタンプ / ラベル / ガーランド /
//   マスキングテープ / 手書き風の波線・下線 / 斜線ハッチ / 植物 / きらめき / 点
// いずれ も 「線 を 少し 揺らす」 「太さ を 変える」 で 手書き の 気配 を 出す。

const DECO_CDN = 'https://t35ty6-rgb.github.io/skeleton-demos/mapsleads-assets/deco';

const DECO_TONE = {
  I: { main:'#1f3556', sub:'#8a6a45', gold:'#cdb47e', leaf:'#6f7a58', ink:'#1f2733' },
  A: { main:'#0071E3', sub:'#8B5CF6', gold:'#EC4899', leaf:'#0071E3', ink:'#0F1B2D' },
  B: { main:'#A88B45', sub:'#6B5528', gold:'#C9A96E', leaf:'#6B5528', ink:'#141210' },
  C: { main:'#9AA6B2', sub:'#C3CCD6', gold:'#B9C3CE', leaf:'#C3CCD6', ink:'#1D1D1F' },
  D: { main:'#C46B3C', sub:'#8B6A45', gold:'#E0C9A6', leaf:'#8B8F5E', ink:'#3B2C1E' },
  E: { main:'#C8102E', sub:'#2F3A34', gold:'#B9A05C', leaf:'#5E6B52', ink:'#1E1B16' },
  F: { main:'#C9A96E', sub:'#8B7548', gold:'#C9A96E', leaf:'#8B7548', ink:'#121212' },
  G: { main:'#D4838A', sub:'#E9A9B4', gold:'#E9C6A0', leaf:'#B9C4A0', ink:'#4A2B31' },
  H: { main:'#D80012', sub:'#7A000B', gold:'#D8A200', leaf:'#7A000B', ink:'#101010' }
};
const DECO_TONE_SET = { I:'navy', A:'navy', D:'warm', G:'pastel', E:'wa', C:'mono', B:'dark', F:'dark', H:'dark' };

function decoTone(style) { return DECO_TONE[style] || DECO_TONE.I; }
function svg(w, h, body) {
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" fill="none">${body}</svg>`);
}
// 手書き の 気配: 直線 を 少し 反らせた path に する
function wob(x1, y1, x2, y2, amp) {
  const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
  const nx = -(y2 - y1), ny = (x2 - x1);
  const len = Math.hypot(nx, ny) || 1;
  return `M${x1},${y1} Q${(mx + (nx / len) * amp).toFixed(1)},${(my + (ny / len) * amp).toFixed(1)} ${x2},${y2}`;
}

/* ---------- 枠 (フレーム) ---------- */
function decoFrame(t, v) {
  const W = 520, H = 400, m = 16;
  const A = t.main, G = t.gold;
  if (v === 0) { // 二重罫 + 四隅の丸
    return svg(W, H,
      `<rect x="${m}" y="${m}" width="${W-m*2}" height="${H-m*2}" rx="18" stroke="${A}" stroke-width="3.5" opacity=".9"/>
       <rect x="${m+10}" y="${m+10}" width="${W-(m+10)*2}" height="${H-(m+10)*2}" rx="12" stroke="${G}" stroke-width="1.6" opacity=".8"/>
       ${[[m,m],[W-m,m],[m,H-m],[W-m,H-m]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="6.5" fill="${G}"/>`).join('')}`);
  }
  if (v === 1) { // 手書き風の1本罫
    return svg(W, H,
      `<path d="${wob(m,m,W-m,m,3)}" stroke="${A}" stroke-width="3" stroke-linecap="round" opacity=".9"/>
       <path d="${wob(W-m,m,W-m,H-m,-3)}" stroke="${A}" stroke-width="3" stroke-linecap="round" opacity=".9"/>
       <path d="${wob(W-m,H-m,m,H-m,3)}" stroke="${A}" stroke-width="3" stroke-linecap="round" opacity=".9"/>
       <path d="${wob(m,H-m,m,m,-3)}" stroke="${A}" stroke-width="3" stroke-linecap="round" opacity=".9"/>`);
  }
  if (v === 2) { // 角だけ太い（額装）
    const c = 74;
    return svg(W, H,
      `<rect x="${m}" y="${m}" width="${W-m*2}" height="${H-m*2}" stroke="${G}" stroke-width="1.4" opacity=".7"/>
       ${[[m,m,1,1],[W-m,m,-1,1],[m,H-m,1,-1],[W-m,H-m,-1,-1]].map(([x,y,sx,sy])=>
        `<path d="M${x},${y+sy*c} L${x},${y} L${x+sx*c},${y}" stroke="${A}" stroke-width="5" stroke-linecap="square" opacity=".95"/>`).join('')}`);
  }
  // v3: 二重 破線 (写真 の 上 に 重ねて も 邪魔 に なら ない)
  return svg(W, H,
    `<rect x="${m}" y="${m}" width="${W-m*2}" height="${H-m*2}" rx="10" stroke="${A}" stroke-width="2.5" stroke-dasharray="12 8" opacity=".8"/>
     <rect x="${m+7}" y="${m+7}" width="${W-(m+7)*2}" height="${H-(m+7)*2}" rx="7" stroke="${G}" stroke-width="1.4" opacity=".7"/>`);
}

/* ---------- 角括弧ボックス ---------- */
function decoBracket(t, v) {
  const W = 520, H = 200, A = t.main, G = t.gold;
  const c = v === 0 ? 40 : v === 1 ? 62 : 30;
  const sw = v === 1 ? 6 : 4;
  const col = v === 2 ? G : A;
  return svg(W, H,
    [[24,24,1,1],[W-24,24,-1,1],[24,H-24,1,-1],[W-24,H-24,-1,-1]].map(([x,y,sx,sy])=>
      `<path d="M${x},${y+sy*c} L${x},${y} L${x+sx*c},${y}" stroke="${col}" stroke-width="${sw}" stroke-linecap="round" opacity=".92"/>`).join('')
    + (v === 2 ? `<path d="${wob(90,H/2,W-90,H/2,2)}" stroke="${A}" stroke-width="2" stroke-dasharray="3 7" opacity=".5"/>` : ''));
}

/* ---------- リボン見出し ---------- */
function decoBanner(t, v) {
  const W = 560, H = 150, A = t.main, G = t.gold, S = t.sub;
  if (v === 0) { // 中央帯 + 両端の折り返し
    return svg(W, H,
      `<path d="M60,40 L500,40 L500,110 L60,110 Z" fill="${A}"/>
       <path d="M60,40 L24,52 L24,98 L60,110 Z" fill="${S}"/>
       <path d="M500,40 L536,52 L536,98 L500,110 Z" fill="${S}"/>
       <path d="M60,110 L40,124 L60,124 Z" fill="${A}" opacity=".55"/>
       <path d="M500,110 L520,124 L500,124 Z" fill="${A}" opacity=".55"/>`);
  }
  if (v === 1) { // 両端が内側に切れ込む
    return svg(W, H,
      `<path d="M20,46 L540,46 L516,75 L540,104 L20,104 L44,75 Z" fill="${G}"/>
       <path d="M64,75 L496,75" stroke="#fff" stroke-width="3" opacity=".4"/>`);
  }
  // v2: 上辺だけの帯 + 影
  return svg(W, H,
    `<path d="M30,52 L530,52 L530,98 L30,98 Z" fill="${A}"/>
     <path d="M30,98 L530,98 L530,106 L30,106 Z" fill="${A}" opacity=".35"/>
     <circle cx="56" cy="75" r="7" fill="${G}"/><circle cx="504" cy="75" r="7" fill="${G}"/>`);
}

/* ---------- スタンプ ---------- */
function decoStamp(t, v) {
  const S = 300, R = 122, cx = 150, cy = 150, A = v === 1 ? t.gold : t.main;
  if (v === 0) { // ギザ縁の二重丸
    const teeth = 44; let d = '';
    for (let i = 0; i < teeth; i++) {
      const a = (i / teeth) * Math.PI * 2, r = i % 2 ? R : R - 9;
      d += `${i ? 'L' : 'M'}${(cx + r * Math.cos(a)).toFixed(1)},${(cy + r * Math.sin(a)).toFixed(1)}`;
    }
    return svg(S, S, `<path d="${d}Z" fill="${A}" opacity=".92"/><circle cx="${cx}" cy="${cy}" r="${R-26}" stroke="#fff" stroke-width="4" opacity=".75"/>`);
  }
  if (v === 1) { // 二重円 + 点線
    return svg(S, S,
      `<circle cx="${cx}" cy="${cy}" r="${R}" stroke="${A}" stroke-width="7" opacity=".9"/>
       <circle cx="${cx}" cy="${cy}" r="${R-16}" stroke="${A}" stroke-width="2" stroke-dasharray="4 8" opacity=".7"/>`);
  }
  // v2: 花形
  const petals = 12; let p = '';
  for (let i = 0; i < petals; i++) {
    const a = (i / petals) * Math.PI * 2;
    p += `<circle cx="${(cx + (R-30) * Math.cos(a)).toFixed(1)}" cy="${(cy + (R-30) * Math.sin(a)).toFixed(1)}" r="26" fill="${A}" opacity=".9"/>`;
  }
  return svg(S, S, p + `<circle cx="${cx}" cy="${cy}" r="${R-38}" fill="${A}"/>`);
}

/* ---------- ガーランド ---------- */
function decoGarland(t, v) {
  const W = 560, H = 140, A = t.main, G = t.gold, S = t.sub;
  const cols = [A, G, S];
  const line = `M10,26 Q${W/2},${v ? 112 : 88} ${W-10},26`;
  let flags = '';
  const n = 9;
  for (let i = 0; i < n; i++) {
    const p = (i + 0.5) / n;
    const x = 10 + (W - 20) * p;
    const y = 26 + 4 * (1 - Math.abs(0.5 - p) * 2) + (v ? 86 : 62) * (1 - Math.pow(2 * p - 1, 2));
    flags += v === 0
      ? `<path d="M${x-17},${y} L${x+17},${y} L${x},${y+38} Z" fill="${cols[i%3]}" opacity=".9"/>`
      : `<circle cx="${x}" cy="${y+18}" r="15" fill="${cols[i%3]}" opacity=".9"/>`;
  }
  return svg(W, H, `<path d="${line}" stroke="${t.ink}" stroke-width="2.5" opacity=".5"/>` + flags);
}

/* ---------- マスキングテープ ---------- */
function decoTape(t, v) {
  const W = 340, H = 110, c = v ? t.gold : t.sub;
  const jag = (y, dir) => {
    let d = `M0,${y}`;
    for (let i = 0; i <= 10; i++) d += ` L${(i * W / 10).toFixed(0)},${(y + (i % 2 ? dir * 5 : 0)).toFixed(0)}`;
    return d;
  };
  const body = `<path d="${jag(34,-1)} L${W},76 ${jag(76,1).replace('M','L').split(' ').reverse().join(' ')} Z" fill="${c}" opacity=".55"/>`;
  const stripes = v
    ? Array.from({length:8},(_,i)=>`<path d="M${20+i*40},30 L${i*40},80" stroke="#fff" stroke-width="7" opacity=".3"/>`).join('')
    : '';
  return svg(W, H, `<g transform="rotate(-4 ${W/2} ${H/2})"><rect x="0" y="32" width="${W}" height="46" fill="${c}" opacity=".5"/>${stripes}
    <path d="${jag(32,-1)}" stroke="${c}" stroke-width="3" opacity=".5"/><path d="${jag(78,1)}" stroke="${c}" stroke-width="3" opacity=".5"/></g>`);
}

/* ---------- 手書き風 波線 ---------- */
function decoWave(t, v) {
  const W = 420, H = 80, c = v === 2 ? t.gold : t.main;
  const amp = [12, 7, 16][v % 3], n = [4, 6, 3][v % 3];
  let d = `M12,${H/2}`;
  for (let i = 0; i < n; i++) {
    const x0 = 12 + (W - 24) * (i / n), x1 = 12 + (W - 24) * ((i + 0.5) / n), x2 = 12 + (W - 24) * ((i + 1) / n);
    d += ` Q${x1.toFixed(0)},${(H/2 + (i % 2 ? amp : -amp) * 2).toFixed(0)} ${x2.toFixed(0)},${H/2}`;
  }
  return svg(W, H, `<path d="${d}" stroke="${c}" stroke-width="${v === 1 ? 3 : 5}" stroke-linecap="round" opacity=".85"/>`);
}

/* ---------- 下線 (強調) ---------- */
function decoUnderline(t, v) {
  const W = 360, H = 60, A = t.main, G = t.gold;
  if (v === 0) return svg(W, H, `<path d="${wob(14,34,W-14,34,4)}" stroke="${G}" stroke-width="14" stroke-linecap="round" opacity=".55"/>`);
  if (v === 1) return svg(W, H, `<path d="${wob(14,28,W-14,28,3)}" stroke="${A}" stroke-width="4" stroke-linecap="round" opacity=".9"/>
                                 <path d="${wob(30,44,W-30,44,3)}" stroke="${A}" stroke-width="2.5" stroke-linecap="round" opacity=".5"/>`);
  return svg(W, H, Array.from({length:12},(_,i)=>`<path d="M${16+i*29},44 L${34+i*29},18" stroke="${A}" stroke-width="3" stroke-linecap="round" opacity=".45"/>`).join(''));
}

/* ---------- 植物 ---------- */
function decoLeaf(t, v) {
  const W = 260, H = 540, c = v % 2 ? t.leaf : t.sub, round = v < 2;
  let body = `<path d="M136,22 C118,130 104,280 74,500" stroke="${c}" stroke-width="5" stroke-linecap="round" opacity=".9"/>`;
  const n = 7 + (v % 3);
  for (let i = 0; i < n; i++) {
    const p = i / (n - 1), y = 52 + p * 420, x = 136 - p * 56, s = 1 - p * 0.32;
    const rx = (round ? 38 : 13) * s, ry = (round ? 32 : 44) * s;
    const tilt = round ? -20 : -38;
    body += `<ellipse cx="${(x-rx*1.05).toFixed(0)}" cy="${y.toFixed(0)}" rx="${rx.toFixed(0)}" ry="${ry.toFixed(0)}" fill="${c}" opacity="${(0.9-p*0.2).toFixed(2)}" transform="rotate(${tilt} ${(x-rx*1.05).toFixed(0)} ${y.toFixed(0)})"/>`;
    body += `<ellipse cx="${(x+rx*1.05).toFixed(0)}" cy="${(y+24*s).toFixed(0)}" rx="${rx.toFixed(0)}" ry="${ry.toFixed(0)}" fill="${c}" opacity="${(0.78-p*0.18).toFixed(2)}" transform="rotate(${-tilt} ${(x+rx*1.05).toFixed(0)} ${(y+24*s).toFixed(0)})"/>`;
    if (v === 2 && i % 3 === 1) body += `<circle cx="${(x+rx*1.6).toFixed(0)}" cy="${(y-14).toFixed(0)}" r="${(9*s).toFixed(0)}" fill="${t.gold}" opacity=".9"/>`;
  }
  return svg(W, H, body);
}

/* ---------- きらめき ---------- */
function decoSpark(t, v) {
  const S = 280, c = v % 2 ? t.gold : t.main;
  const star = (cx, cy, r, o) =>
    `<path d="M${cx},${cy-r} C${cx+r*0.14},${cy-r*0.14} ${cx+r*0.14},${cy-r*0.14} ${cx+r},${cy} C${cx+r*0.14},${cy+r*0.14} ${cx+r*0.14},${cy+r*0.14} ${cx},${cy+r} C${cx-r*0.14},${cy+r*0.14} ${cx-r*0.14},${cy+r*0.14} ${cx-r},${cy} C${cx-r*0.14},${cy-r*0.14} ${cx-r*0.14},${cy-r*0.14} ${cx},${cy-r} Z" fill="${c}" opacity="${o}"/>`;
  const sets = [
    [[140,104,84,.95],[62,196,42,.75],[210,190,30,.6]],
    [[130,130,100,.9],[222,62,36,.7]],
    [[96,96,66,.9],[182,162,52,.8],[72,212,28,.6],[222,232,20,.5]],
    [[140,140,112,.92]]
  ][v % 4];
  return svg(S, S, sets.map(s => star(...s)).join(''));
}

/* ---------- コーナー ---------- */
function decoCorner(t, v) {
  const S = 280, A = t.main, G = t.gold;
  if (v === 0) return svg(S, S,
    `<path d="M0,224 C0,100 100,0 224,0" stroke="${G}" stroke-width="7" opacity=".85"/>
     <path d="M0,158 C0,71 71,0 158,0" stroke="${A}" stroke-width="2.5" opacity=".45"/>
     <circle cx="224" cy="0" r="9" fill="${G}"/><circle cx="0" cy="224" r="9" fill="${G}"/>`);
  if (v === 1) return svg(S, S,
    `<path d="M0,0 L248,0 L248,15 L15,15 L15,248 L0,248 Z" fill="${G}" opacity=".85"/>
     <path d="M38,38 L214,38 M38,38 L38,214" stroke="${A}" stroke-width="4" opacity=".5"/>`);
  return svg(S, S,
    `<path d="M12,258 C12,122 122,12 258,12" stroke="${G}" stroke-width="5" opacity=".8"/>` +
    Array.from({length:5},(_,i)=>{const a=(Math.PI/2)*(i/4);
      return `<circle cx="${(12+246*Math.sin(a)).toFixed(0)}" cy="${(258-246*Math.sin(a)).toFixed(0)}" r="${7-i}" fill="${A}" opacity=".7"/>`;}).join(''));
}

/* ---------- 和 の 文様 ---------- */
function decoWa(t, v) {
  const W = 300, H = 230, c = t.ink, g = t.gold;
  let body = '';
  if (v === 0) {
    for (let r = 0; r < 3; r++) for (let i = 0; i < 5; i++) {
      const cx = 30 + i * 62 + (r % 2 ? 31 : 0), cy = 44 + r * 60;
      body += `<path d="M${cx-36},${cy} a36,36 0 0,1 72,0" stroke="${r === 1 ? g : c}" stroke-width="3" opacity=".4"/>`;
      body += `<path d="M${cx-22},${cy} a22,22 0 0,1 44,0" stroke="${r === 1 ? g : c}" stroke-width="2.5" opacity=".3"/>`;
    }
  } else {
    for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) {
      const cx = 44 + i * 68, cy = 44 + j * 68;
      body += `<circle cx="${cx}" cy="${cy}" r="34" stroke="${(i + j) % 2 ? g : c}" stroke-width="3" opacity=".35"/>`;
    }
  }
  return svg(W, H, body);
}

/* ---------- リボン (小) ---------- */
function decoRibbon(t, v) {
  const W = 220, H = 130, c = t.gold;
  return svg(W, H, v === 0
    ? `<path d="M12,65 C64,20 156,20 208,65 C156,110 64,110 12,65 Z" fill="${c}" opacity=".9"/>
       <path d="M46,65 C82,44 138,44 174,65 C138,86 82,86 46,65 Z" fill="#fff" opacity=".3"/>`
    : `<path d="M16,34 L204,34 L182,65 L204,96 L16,96 L38,65 Z" fill="${c}" opacity=".9"/>
       <path d="M50,56 L170,56" stroke="#fff" stroke-width="4" opacity=".35"/>`);
}

/* ---------- 点 ---------- */
function decoDot(t, v) {
  const W = 260, H = 70, c = v ? t.gold : t.sub;
  let body = '';
  for (let i = 0; i < 10; i++) {
    const r = v ? 3 + i * 0.9 : 4 + (i % 3) * 3;
    body += `<circle cx="${14+i*25}" cy="${34+(v?0:(i%2?-9:9))}" r="${r.toFixed(1)}" fill="${c}" opacity="${(0.35+(i%3)*0.2).toFixed(2)}"/>`;
  }
  return svg(W, H, body);
}

const DECO_KINDS = {
  frame:     { fn: decoFrame,     variants: 4 },
  bracket:   { fn: decoBracket,   variants: 3 },
  banner:    { fn: decoBanner,    variants: 3 },
  stamp:     { fn: decoStamp,     variants: 3 },
  garland:   { fn: decoGarland,   variants: 2 },
  tape:      { fn: decoTape,      variants: 2 },
  wave:      { fn: decoWave,      variants: 3 },
  underline: { fn: decoUnderline, variants: 3 },
  leaf:      { fn: decoLeaf,      variants: 4 },
  spark:     { fn: decoSpark,     variants: 4 },
  corner:    { fn: decoCorner,    variants: 3 },
  wa:        { fn: decoWa,        variants: 2 },
  ribbon:    { fn: decoRibbon,    variants: 2 },
  dot:       { fn: decoDot,       variants: 2 }
};

let decoLibTier = null;
const _decoProbe = new Map(), _decoChecked = new Map();
function probeDeco(url) {
  if (_decoProbe.has(url)) return _decoProbe.get(url);
  const p = new Promise((res) => {
    const im = new Image();
    im.onload = () => res(true); im.onerror = () => res(false);
    im.src = url; setTimeout(() => res(false), 4000);
  });
  _decoProbe.set(url, p); return p;
}
async function mlEnsureDecoLib(style) {
  const set = DECO_TONE_SET[style] || 'navy';
  if (_decoChecked.has(set)) { decoLibTier = _decoChecked.get(set); return decoLibTier; }
  const ok = await probeDeco(`${DECO_CDN}/${set}/frame_01.png`);
  const tier = ok ? set : false;
  _decoChecked.set(set, tier); decoLibTier = tier; return tier;
}

function mlDeco(style, seed, kind, slot) {
  const k = DECO_KINDS[kind];
  if (!k) return '';
  let h = 2166136261;
  const s = String(seed) + '|' + kind + '|' + slot;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  const v = Math.abs(h) % k.variants;
  if (decoLibTier) return `${DECO_CDN}/${decoLibTier}/${kind}_${String(v + 1).padStart(2, '0')}.png`;
  return k.fn(decoTone(style), v);
}

if (typeof self !== 'undefined') {
  self.mlDeco = mlDeco; self.mlEnsureDecoLib = mlEnsureDecoLib;
  self.DECO_KINDS = DECO_KINDS; self.DECO_TONE = DECO_TONE; self.DECO_TONE_SET = DECO_TONE_SET;
}
