// MapsLeads · あしらい の 引き出し  v2.14.0
//
// いろは の deco-euca / deco-olive / deco-spark / deco-corner / deco-gold に あたる 飾り。
// 二段構え:
//   1) 内蔵 SVG (通信 なし で すぐ 出る。 テイスト の 色 に 合わせて 描く)
//   2) Gemini で 作った 画像 ライブラリ (assets/generate-deco.mjs)。 置か れたら 自動 で そちら を 使う。
//
// 引き出し の 中身 = 種類 (leaf / spark / corner / ribbon / wa / dot) × 変種。

const DECO_CDN = 'https://t35ty6-rgb.github.io/skeleton-demos/mapsleads-assets/deco';

// テイスト 別 の 色 (Style I = 紺 × 茶金 が 基準)
const DECO_TONE = {
  I: { leaf: '#8a6a45', leaf2: '#6f7a58', gold: '#cdb47e', ink: '#1f3556' },
  A: { leaf: '#8B5CF6', leaf2: '#0071E3', gold: '#EC4899', ink: '#0F1B2D' },
  B: { leaf: '#6B5528', leaf2: '#A88B45', gold: '#A88B45', ink: '#141210' },
  C: { leaf: '#C3CCD6', leaf2: '#D8DEE6', gold: '#9AA6B2', ink: '#1D1D1F' },
  D: { leaf: '#8B6A45', leaf2: '#C46B3C', gold: '#E0C9A6', ink: '#3B2C1E' },
  E: { leaf: '#2F3A34', leaf2: '#7A8B6F', gold: '#C8102E', ink: '#1E1B16' },
  F: { leaf: '#8B7548', leaf2: '#C9A96E', gold: '#C9A96E', ink: '#121212' },
  G: { leaf: '#D4838A', leaf2: '#E9A9B4', gold: '#E9C6A0', ink: '#4A2B31' },
  H: { leaf: '#7A000B', leaf2: '#D80012', gold: '#D8A200', ink: '#101010' }
};

function decoTone(style) { return DECO_TONE[style] || DECO_TONE.I; }

function svg(w, h, body) {
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${body}</svg>`
  );
}

// ---- 葉 の 枝 (ユーカリ / オリーブ 相当) ----
function decoLeaf(t, variant) {
  const c = variant % 2 ? t.leaf2 : t.leaf;
  const round = variant < 2; // 丸い葉 (ユーカリ) か 細い葉 (オリーブ) か
  const n = 7 + (variant % 3);
  let body = `<path d="M124,20 C110,120 96,250 78,470" fill="none" stroke="${c}" stroke-width="5" stroke-linecap="round" opacity="0.9"/>`;
  for (let i = 0; i < n; i++) {
    const p = i / (n - 1);
    const y = 46 + p * 400;
    const x = 124 - p * 44;
    const s = 1 - p * 0.35;
    const rx = (round ? 40 : 15) * s, ry = (round ? 34 : 46) * s;
    const rot = round ? -18 : -34;
    body += `<ellipse cx="${(x - rx * 0.9).toFixed(0)}" cy="${y.toFixed(0)}" rx="${rx.toFixed(0)}" ry="${ry.toFixed(0)}" fill="${c}" opacity="${(0.92 - p * 0.18).toFixed(2)}" transform="rotate(${rot} ${(x - rx * 0.9).toFixed(0)} ${y.toFixed(0)})"/>`;
    body += `<ellipse cx="${(x + rx * 0.9).toFixed(0)}" cy="${(y + 22 * s).toFixed(0)}" rx="${rx.toFixed(0)}" ry="${ry.toFixed(0)}" fill="${c}" opacity="${(0.8 - p * 0.16).toFixed(2)}" transform="rotate(${-rot} ${(x + rx * 0.9).toFixed(0)} ${(y + 22 * s).toFixed(0)})"/>`;
  }
  return svg(250, 520, body);
}

// ---- きらめき ----
function decoSpark(t, variant) {
  const c = variant % 2 ? t.gold : t.leaf2;
  const star = (cx, cy, r, o) =>
    `<path d="M${cx},${cy - r} C${cx + r * 0.16},${cy - r * 0.16} ${cx + r * 0.16},${cy - r * 0.16} ${cx + r},${cy} C${cx + r * 0.16},${cy + r * 0.16} ${cx + r * 0.16},${cy + r * 0.16} ${cx},${cy + r} C${cx - r * 0.16},${cy + r * 0.16} ${cx - r * 0.16},${cy + r * 0.16} ${cx - r},${cy} C${cx - r * 0.16},${cy - r * 0.16} ${cx - r * 0.16},${cy - r * 0.16} ${cx},${cy - r} Z" fill="${c}" opacity="${o}"/>`;
  const sets = [
    [[130, 96, 78, 0.95], [56, 182, 40, 0.75], [196, 176, 28, 0.6]],
    [[120, 120, 92, 0.9], [206, 58, 34, 0.7]],
    [[88, 88, 62, 0.9], [168, 150, 48, 0.8], [66, 196, 26, 0.6], [206, 216, 18, 0.5]],
    [[128, 128, 104, 0.92]]
  ][variant % 4];
  return svg(260, 260, sets.map((s) => star(s[0], s[1], s[2], s[3])).join(''));
}

// ---- コーナー 飾り ----
function decoCorner(t, variant) {
  const c = t.gold, c2 = t.leaf;
  const v = variant % 3;
  let body = '';
  if (v === 0) {
    body = `<path d="M0,210 C0,94 94,0 210,0" fill="none" stroke="${c}" stroke-width="7" opacity="0.85"/>
            <path d="M0,150 C0,67 67,0 150,0" fill="none" stroke="${c2}" stroke-width="3" opacity="0.5"/>
            <circle cx="210" cy="0" r="9" fill="${c}"/><circle cx="0" cy="210" r="9" fill="${c}"/>`;
  } else if (v === 1) {
    body = `<path d="M0,0 L230,0 L230,14 L14,14 L14,230 L0,230 Z" fill="${c}" opacity="0.8"/>
            <path d="M34,34 L200,34" stroke="${c2}" stroke-width="4" opacity="0.55"/>
            <path d="M34,34 L34,200" stroke="${c2}" stroke-width="4" opacity="0.55"/>`;
  } else {
    body = `<path d="M10,240 C10,110 110,10 240,10" fill="none" stroke="${c}" stroke-width="5" opacity="0.8"/>`;
    for (let i = 0; i < 5; i++) {
      const a = (Math.PI / 2) * (i / 4);
      const x = 10 + 230 * Math.sin(a), y = 240 - 230 * Math.sin(Math.PI / 2 - a);
      body += `<circle cx="${x.toFixed(0)}" cy="${(y + 230).toFixed(0)}" r="${7 - i}" fill="${c2}" opacity="0.7"/>`;
    }
  }
  return svg(260, 260, body);
}

// ---- 金 の リボン ----
function decoRibbon(t, variant) {
  const c = t.gold;
  const v = variant % 2;
  const body = v === 0
    ? `<path d="M10,60 C60,18 140,18 190,60 C140,102 60,102 10,60 Z" fill="${c}" opacity="0.9"/>
       <path d="M40,60 C74,40 126,40 160,60 C126,80 74,80 40,60 Z" fill="#fff" opacity="0.28"/>`
    : `<path d="M14,30 L186,30 L166,60 L186,90 L14,90 L34,60 Z" fill="${c}" opacity="0.9"/>
       <path d="M44,52 L156,52" stroke="#fff" stroke-width="4" opacity="0.35"/>`;
  return svg(200, 120, body);
}

// ---- 和 の 意匠 (青海波 · 七宝) ----
function decoWa(t, variant) {
  const c = t.ink, g = t.gold;
  let body = '';
  if (variant % 2 === 0) {
    for (let r = 0; r < 3; r++) for (let i = 0; i < 4; i++) {
      const cx = 30 + i * 60 + (r % 2 ? 30 : 0), cy = 40 + r * 52;
      body += `<path d="M${cx - 34},${cy} a34,34 0 0,1 68,0" fill="none" stroke="${r === 1 ? g : c}" stroke-width="3" opacity="0.4"/>`;
      body += `<path d="M${cx - 20},${cy} a20,20 0 0,1 40,0" fill="none" stroke="${r === 1 ? g : c}" stroke-width="2.5" opacity="0.3"/>`;
    }
  } else {
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      const cx = 44 + i * 62, cy = 40 + j * 56;
      body += `<circle cx="${cx}" cy="${cy}" r="30" fill="none" stroke="${(i + j) % 2 ? g : c}" stroke-width="3" opacity="0.35"/>`;
    }
  }
  return svg(260, 200, body);
}

// ---- 点の帯 ----
function decoDot(t, variant) {
  const c = variant % 2 ? t.gold : t.leaf;
  let body = '';
  for (let i = 0; i < 9; i++) {
    const r = 4 + (i % 3) * 3;
    body += `<circle cx="${14 + i * 24}" cy="${28 + (i % 2 ? -8 : 8)}" r="${r}" fill="${c}" opacity="${0.35 + (i % 3) * 0.2}"/>`;
  }
  return svg(240, 60, body);
}

const DECO_KINDS = {
  leaf: { fn: decoLeaf, variants: 4 },
  spark: { fn: decoSpark, variants: 4 },
  corner: { fn: decoCorner, variants: 3 },
  ribbon: { fn: decoRibbon, variants: 2 },
  wa: { fn: decoWa, variants: 2 },
  dot: { fn: decoDot, variants: 2 }
};

// テイスト → 生成 ライブラリ の トーン
const DECO_TONE_SET = { I:'navy', A:'navy', D:'warm', G:'pastel', E:'wa', C:'mono', B:'dark', F:'dark', H:'dark' };

// 生成 ライブラリ が 置か れて いれば そちら を 使う
let decoLibTier = null; // トーン 名 | false(無い) | null(未調査)
const _decoChecked = new Map();
const _decoProbe = new Map();
function probeDeco(url) {
  if (_decoProbe.has(url)) return _decoProbe.get(url);
  const p = new Promise((res) => {
    const im = new Image();
    im.onload = () => res(true);
    im.onerror = () => res(false);
    im.src = url;
    setTimeout(() => res(false), 4000);
  });
  _decoProbe.set(url, p);
  return p;
}
async function mlEnsureDecoLib(style) {
  const set = DECO_TONE_SET[style] || 'navy';
  if (_decoChecked.has(set)) { decoLibTier = _decoChecked.get(set); return decoLibTier; }
  const ok = await probeDeco(`${DECO_CDN}/${set}/leaf_01.png`);
  const tier = ok ? set : false;
  _decoChecked.set(set, tier);
  decoLibTier = tier;
  return tier;
}

// 引き出し から 1 枚 取る (店 ごと に 決まる)
function mlDeco(style, seed, kind, slot) {
  const k = DECO_KINDS[kind];
  if (!k) return '';
  let h = 2166136261;
  const s = String(seed) + '|' + kind + '|' + slot;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  const v = Math.abs(h) % k.variants;
  if (decoLibTier) {
    return `${DECO_CDN}/${decoLibTier}/${kind}_${String(v + 1).padStart(2, '0')}.png`;
  }
  return k.fn(decoTone(style), v);
}

if (typeof self !== 'undefined') {
  self.mlDeco = mlDeco;
  self.mlEnsureDecoLib = mlEnsureDecoLib;
  self.DECO_KINDS = DECO_KINDS;
  self.DECO_TONE = DECO_TONE;
  self.DECO_TONE_SET = DECO_TONE_SET;
}
