// MapsLeads v2.5.0 - Places API proxy client (background service worker)
// v2.5.0: 60 件 の 壁 を 撤廃。 エリア を 自動 で 格子 分割 し、 マス ごと に 再検索 して 重複 除去 で 積み上げる。
importScripts('config.js', 'license.js');

const state = {
  running: false,
  rows: [],
  filters: null,
  query: '',
  mode: 'area', // 'area' | 'storeName'
  progress: { phase: 'idle', current: 0, total: 0, msg: '' },
  lastError: null,
  quota: null
};

function reset() {
  state.running = false;
  state.rows = [];
  state.progress = { phase: 'idle', current: 0, total: 0, msg: '' };
  state.lastError = null;
}

async function broadcastProgress() {
  try {
    await chrome.runtime.sendMessage({ type: 'BG_PROGRESS', progress: state.progress, count: state.rows.length, quota: state.quota });
  } catch (_) {}
  const t = state.progress;
  const badge = t.phase === 'idle' ? '' : `${t.current}/${t.total || '?'}`.slice(0, 6);
  try { chrome.action.setBadgeText({ text: badge }); } catch (_) {}
  try { chrome.action.setBadgeBackgroundColor({ color: '#0F1B2D' }); } catch (_) {}
}

async function updateProgress(phase, current, total, msg) {
  state.progress = { phase, current, total, msg: msg || '' };
  await broadcastProgress();
}

async function callProxy(endpointName, body, licenseKey) {
  const url = self.MAPSLEADS_API.BASE + self.MAPSLEADS_API.ENDPOINTS[endpointName];
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-License-Key': licenseKey || ''
    },
    body: JSON.stringify(body || {})
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch (_) { data = { rawBody: text }; }
  return { status: res.status, data, ok: res.ok };
}

async function searchAllPages({ textQuery, includedType, maxResults, licenseKey, locationBias, maxPages }) {
  const collected = [];
  let pageToken = null;
  let lastQuota = null;
  const pages = maxPages || 3;

  for (let page = 0; page < pages && collected.length < maxResults; page++) {
    const body = { textQuery, pageSize: 20 };
    if (includedType) body.includedType = includedType;
    if (pageToken) body.pageToken = pageToken;
    if (locationBias) body.locationBias = locationBias;

    const res = await callProxy('searchStores', body, licenseKey);
    if (!res.ok) {
      const err = new Error(res.data?.message || 'searchStores 失敗');
      err.code = res.data?.code || 'SEARCH_FAIL';
      err.status = res.status;
      err.detail = res.data;
      throw err;
    }

    const places = res.data.places || [];
    for (const p of places) {
      if (collected.length >= maxResults) break;
      collected.push(p);
    }

    lastQuota = res.data.quota || lastQuota;
    pageToken = res.data.nextPageToken;
    if (!pageToken) break;

    await new Promise((r) => setTimeout(r, 1500));
  }

  return { places: collected, quota: lastQuota };
}

// ==== 80 件 超え 用: エリア を 自動 分割 して 広域 スキャン ====
// Google の text search は 1 クエリ 最大 60 件 (20 件 × 3 ページ) しか 返さ ない。
// そこで 1 回目 の 結果 の 座標 から 範囲 を 割り出し、 その 範囲 を 格子 に 切って
// 1 マス ずつ locationBias を 付けて 再検索 し、 placeId で 重複 を 除いて 積み上げる。
function toRad(d) { return (d * Math.PI) / 180; }

function bboxOfPlaces(places) {
  const pts = places
    .map((p) => p.location)
    .filter((l) => l && typeof l.latitude === 'number' && typeof l.longitude === 'number');
  if (pts.length === 0) return null;
  let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
  for (const l of pts) {
    if (l.latitude < minLat) minLat = l.latitude;
    if (l.latitude > maxLat) maxLat = l.latitude;
    if (l.longitude < minLng) minLng = l.longitude;
    if (l.longitude > maxLng) maxLng = l.longitude;
  }
  return { minLat, maxLat, minLng, maxLng };
}

function buildTiles(bbox, n) {
  // 端 の 店 が 枠外 に 落ちない よう 15% 広げる (潰れて いる 場合 の 最低幅 も 確保)
  const spanLat = Math.max(bbox.maxLat - bbox.minLat, 0.02);
  const spanLng = Math.max(bbox.maxLng - bbox.minLng, 0.02);
  const minLat = bbox.minLat - spanLat * 0.15;
  const maxLat = bbox.maxLat + spanLat * 0.15;
  const minLng = bbox.minLng - spanLng * 0.15;
  const maxLng = bbox.maxLng + spanLng * 0.15;
  const dLat = (maxLat - minLat) / n;
  const dLng = (maxLng - minLng) / n;
  const cLat0 = (minLat + maxLat) / 2;
  const cLng0 = (minLng + maxLng) / 2;

  const tiles = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const lat = minLat + dLat * (i + 0.5);
      const lng = minLng + dLng * (j + 0.5);
      const mLat = dLat * 111320;
      const mLng = dLng * 111320 * Math.cos(toRad(lat));
      // 対角 の 半分 + 少し 重ね て 取りこぼし を 防ぐ
      const radius = Math.min(50000, Math.max(400, (Math.sqrt(mLat * mLat + mLng * mLng) / 2) * 1.1));
      tiles.push({ center: { latitude: lat, longitude: lng }, radius });
    }
  }
  // 中心 に 近い マス から (店 が 濃い ので 早く 貯まる)
  tiles.sort((a, b) => {
    const da = (a.center.latitude - cLat0) ** 2 + (a.center.longitude - cLng0) ** 2;
    const db = (b.center.latitude - cLat0) ** 2 + (b.center.longitude - cLng0) ** 2;
    return da - db;
  });
  return tiles;
}

async function searchWide({ textQuery, maxResults, licenseKey }) {
  const seen = new Map();
  let quota = null;
  const push = (arr) => {
    for (const p of arr || []) {
      if (p && p.id && !seen.has(p.id)) seen.set(p.id, p);
    }
  };

  // 1st pass: 普通 の text search (最大 60 件)
  const first = await searchAllPages({
    textQuery,
    maxResults: Math.min(maxResults, 60),
    licenseKey,
    maxPages: 3
  });
  push(first.places);
  if (first.quota) quota = first.quota;
  await updateProgress('searching', seen.size, maxResults, `${seen.size} 件 取得`);

  if (seen.size >= maxResults) {
    return { places: Array.from(seen.values()).slice(0, maxResults), quota };
  }

  const bbox = bboxOfPlaces(Array.from(seen.values()));
  if (!bbox) return { places: Array.from(seen.values()), quota };

  // 2nd pass: 格子 スキャン
  const n = maxResults <= 120 ? 3 : (maxResults <= 250 ? 4 : 5);
  const tiles = buildTiles(bbox, n);

  let emptyStreak = 0;
  for (let t = 0; t < tiles.length; t++) {
    if (!state.running) break;
    if (seen.size >= maxResults) break;
    const before = seen.size;
    let r = null;
    try {
      r = await searchAllPages({
        textQuery,
        maxResults: 60,
        licenseKey,
        maxPages: 2,
        locationBias: { circle: { center: tiles[t].center, radius: tiles[t].radius } }
      });
    } catch (e) {
      // 使用量 上限 · ライセンス 系 は 中断、 それ 以外 の 1 マス 失敗 は 無視 して 次 へ
      if (e.code === 'MONTHLY_CAP_EXCEEDED' || e.code === 'REVOKED' || e.code === 'INVALID_KEY') throw e;
      continue;
    }
    push(r.places);
    if (r.quota) quota = r.quota;
    await updateProgress('searching', seen.size, maxResults, `広域 スキャン ${t + 1}/${tiles.length} · ${seen.size} 件`);
    if (seen.size === before) {
      emptyStreak++;
      if (emptyStreak >= 5) break; // これ以上 掘って も 増えない
    } else {
      emptyStreak = 0;
    }
    await new Promise((r2) => setTimeout(r2, 400));
  }

  return { places: Array.from(seen.values()).slice(0, maxResults), quota };
}

async function enrichSocialForPlace(place, licenseKey) {
  if (!place.website) return { instagramUrl: '', lineUrl: '' };

  // 予約 サイト しか 無い 場合 は 自社 HP じゃ ないので socil scrape の 対象 外
  if (place.websiteIsBookingOnly) return { instagramUrl: '', lineUrl: '' };

  try {
    const res = await callProxy('enrichSocial', { websiteUrl: place.website }, licenseKey);
    if (!res.ok) return { instagramUrl: '', lineUrl: '' };
    return {
      instagramUrl: res.data.instagramUrl || '',
      lineUrl: res.data.lineUrl || ''
    };
  } catch (_) {
    return { instagramUrl: '', lineUrl: '' };
  }
}

function toRow(place, social) {
  return {
    name: place.name,
    category: place.category,
    rating: place.rating != null ? place.rating : '',
    reviewCount: place.userRatingCount || '',
    phone: place.phone,
    addressFull: place.address,
    area: '',
    hours: '',
    website: place.website,
    hasOwnWebsite: !!(place.website && !place.websiteIsBookingOnly),
    websiteIsBookingOnly: place.websiteIsBookingOnly,
    instagramUrl: social?.instagramUrl || '',
    lineUrl: social?.lineUrl || '',
    hasInstagram: !!(social?.instagramUrl),
    hasLineOfficial: !!(social?.lineUrl),
    mapsUrl: place.mapsUrl,
    placeId: place.id,
    photoNames: Array.isArray(place.photoNames) ? place.photoNames : [],
    photoCount: place.photoCount || 0,
    photos: [],
    types: place.types || []
  };
}

async function runJob({ mode, storeName, area, category, maxResults, enrichSocial, licenseKey }) {
  if (state.running) throw new Error('すでに実行中');
  reset();
  state.running = true;
  state.mode = mode || 'area';
  state.query = mode === 'storeName' ? storeName : [area, category].filter(Boolean).join(' ');

  await updateProgress('starting', 0, 0, '検索 準備 中');

  const textQuery = state.query;
  if (!textQuery) throw new Error('検索 クエリ が 空 です');

  try {
    const cap = Math.min(500, Math.max(1, maxResults || 20));

    await updateProgress('searching', 0, cap, '公式 サービス 呼び出し 中');
    const { places, quota } = await searchWide({
      textQuery,
      maxResults: cap,
      licenseKey
    });

    state.quota = quota;
    await updateProgress('search_done', places.length, places.length, `${places.length} 件 発見`);

    // 基本 行 を まず 作成
    state.rows = places.map((p) => toRow(p, null));

    // enrichSocial: 各 店舗 の HP を 読み込み Insta/LINE 拾う
    if (enrichSocial) {
      for (let i = 0; i < state.rows.length; i++) {
        if (!state.running) break;
        const row = state.rows[i];
        await updateProgress('enrich', i + 1, state.rows.length, `SNS 確認: ${row.name}`);
        if (row.website && !row.websiteIsBookingOnly) {
          const social = await enrichSocialForPlace(places[i], licenseKey);
          row.instagramUrl = social.instagramUrl;
          row.lineUrl = social.lineUrl;
          row.hasInstagram = !!social.instagramUrl;
          row.hasLineOfficial = !!social.lineUrl;
        }
        await new Promise((r) => setTimeout(r, 300));
      }
    } else {
      await updateProgress('skip_enrich', state.rows.length, state.rows.length, 'SNS 補完 スキップ');
    }

    await updateProgress('done', state.rows.length, state.rows.length, `完了 · ${state.rows.length} 件`);
  } catch (e) {
    state.lastError = String(e.message || e);
    if (e.code === 'MONTHLY_CAP_EXCEEDED') {
      await updateProgress('cap_exceeded', 0, 0, state.lastError);
    } else if (e.code === 'REVOKED' || e.code === 'INVALID_KEY') {
      await updateProgress('license_error', 0, 0, state.lastError);
    } else {
      await updateProgress('error', 0, 0, state.lastError);
    }
    throw e;
  } finally {
    state.running = false;
    await broadcastProgress();
    try {
      chrome.action.setBadgeText({ text: state.rows.length ? String(state.rows.length) : '' });
    } catch (_) {}
  }

  return state.rows;
}

async function stopJob() {
  state.running = false;
  await updateProgress('stopped', 0, 0, '停止しました');
}

async function fetchPhotoUrl(photoName, licenseKey, maxWidthPx) {
  const res = await callProxy('getPhoto', { photoName, maxWidthPx: maxWidthPx || 1600 }, licenseKey);
  if (!res.ok) return null;
  return res.data.photoUri || null;
}

async function verifyLicenseServer(licenseKey) {
  try {
    const res = await callProxy('verifyLicense', {}, licenseKey);
    return res.data;
  } catch (_) {
    return { valid: false, code: 'NETWORK_ERROR' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === 'BG_START') {
        const localLic = await self.MapsLeadsLicense.checkAndConsume();
        if (!localLic.allowed) {
          sendResponse({ ok: false, error: 'license_denied', reason: localLic.reason, needKey: !!localLic.needKey });
          return;
        }

        const licenseKey = await self.MapsLeadsLicense.getKey();
        if (!licenseKey) {
          // v2.0.0 は API 前提 なので trial mode 廃止。 キー 必須。
          sendResponse({ ok: false, error: 'license_denied', reason: 'trial_exhausted', needKey: true });
          return;
        }

        runJob({ ...msg.payload, licenseKey }).then(
          (rows) => chrome.storage.local.set({
            ml_last_result: {
              rows,
              query: state.query,
              mode: state.mode,
              filters: state.filters,
              quota: state.quota,
              at: Date.now()
            }
          }),
          (e) => chrome.storage.local.set({
            ml_last_error: {
              message: String(e.message || e),
              code: e.code || 'ERR',
              at: Date.now()
            }
          })
        );
        sendResponse({ ok: true, started: true });
        return;
      }
      if (msg.type === 'LICENSE_STATUS') {
        const st = await self.MapsLeadsLicense.status();
        sendResponse({ ok: true, status: st });
        return;
      }
      if (msg.type === 'LICENSE_VERIFY_SERVER') {
        const key = await self.MapsLeadsLicense.getKey();
        if (!key) { sendResponse({ ok: false, error: 'no_key' }); return; }
        const st = await verifyLicenseServer(key);
        sendResponse({ ok: true, status: st });
        return;
      }
      if (msg.type === 'LICENSE_REGISTER') {
        const res = await self.MapsLeadsLicense.registerLicense(msg.key);
        sendResponse(res);
        return;
      }
      if (msg.type === 'LICENSE_RESET') {
        await self.MapsLeadsLicense.reset();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === 'BG_STATUS') {
        sendResponse({
          ok: true,
          running: state.running,
          progress: state.progress,
          rows: state.rows.length,
          quota: state.quota
        });
        return;
      }
      if (msg.type === 'BG_RESULT') {
        sendResponse({ ok: true, rows: state.rows, quota: state.quota });
        return;
      }
      if (msg.type === 'BG_STOP') {
        await stopJob();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === 'GET_PHOTO') {
        const key = await self.MapsLeadsLicense.getKey();
        const uri = await fetchPhotoUrl(msg.photoName, key, msg.maxWidthPx);
        sendResponse({ ok: !!uri, photoUri: uri });
        return;
      }
      if (msg.type === 'GENERATE_COPY') {
        const key = await self.MapsLeadsLicense.getKey();
        if (!key) { sendResponse({ ok: false, error: 'no_license' }); return; }
        const { ml_philosophy } = await chrome.storage.local.get('ml_philosophy');
        const philosophy = (ml_philosophy && ml_philosophy.text) || '';
        if (!philosophy.trim() || philosophy.trim().length < 20) {
          sendResponse({ ok: false, error: 'no_philosophy', skip: true });
          return;
        }
        const payload = { philosophy, store: msg.store };
        if (msg.perStoreContext && String(msg.perStoreContext).trim().length > 0) {
          payload.perStoreContext = String(msg.perStoreContext).trim();
        }
        const res = await callProxy('generateCopy', payload, key);
        if (!res.ok) {
          sendResponse({ ok: false, error: res.data?.code || res.data?.error || 'generate_failed' });
          return;
        }
        sendResponse({ ok: true, copy: res.data.copy, quota: res.data.quota, usage: res.data.usage });
        return;
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e.message || e) });
    }
  })();
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: '' });
});

globalThis.__mapsleads = { runJob, stopJob, state };
