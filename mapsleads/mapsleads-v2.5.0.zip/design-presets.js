// MapsLeads · デザイン の 注文 プリセット (v2.5.0)
// popup / mockup の 両方 が 読み込む。 クリック だけ で
//  (1) AI コピー に 渡す 指示文 (brief)
//  (2) preview の 見た目 (style / fontScale / colorFilter / photo density)
// が 決まる。
const ML_DESIGN_GROUPS = [
  {
    key: 'vibe',
    label: '全体 の 雰囲気',
    options: [
      { v: 'auto',    l: 'おまかせ',        brief: '' },
      { v: 'pop',     l: 'ポップで明るい',  brief: '全体を明るくポップに。丸みのある形と元気のある見出しで、堅苦しさを出さない。', style: 'H' },
      { v: 'lux',     l: '上品・高級感',    brief: '余白を広く取り、上品で高級感のある落ち着いたトーンにする。装飾は最小限。', style: 'B' },
      { v: 'natural', l: 'ナチュラル・やさしい', brief: 'やわらかく親しみのあるトーン。温かみのある言葉づかいで、押し付けがましくしない。', style: 'D' },
      { v: 'cute',    l: 'かわいい・やわらか', brief: 'やさしい色と丸い形で、かわいらしい印象にする。言葉も柔らかくする。', style: 'G' },
      { v: 'wa',      l: '和・落ち着き',    brief: '和の落ち着いたトーン。余白を大事にし、言葉は簡潔にする。', style: 'E' },
      { v: 'sharp',   l: '都会的・シャープ', brief: '都会的でシャープなトーン。無駄を削り、短く言い切る見出しにする。', style: 'F' },
      { v: 'clean',   l: '清潔・信頼感',    brief: '清潔で信頼感のあるトーン。誇張を避け、事実を落ち着いて伝える。', style: 'C' }
    ]
  },
  {
    key: 'color',
    label: '色づかい',
    options: [
      { v: 'auto',     l: 'おまかせ',   brief: '' },
      { v: 'colorful', l: 'カラフル',   brief: '色数を多めに、明るい配色で楽しい印象にする。', filter: 'saturate(1.35)' },
      { v: 'calm',     l: '落ち着いた色', brief: '彩度を抑えた落ち着いた配色にする。', filter: 'saturate(0.72)' },
      { v: 'mono',     l: 'モノトーン', brief: 'ほぼ白黒のモノトーンでまとめる。', filter: 'grayscale(0.92)' },
      { v: 'warm',     l: '暖色（赤・橙）', brief: '暖色を主役にした温かい配色にする。', filter: 'sepia(0.22) saturate(1.25) hue-rotate(-12deg)' },
      { v: 'cool',     l: '寒色（青・緑）', brief: '寒色を主役にした涼しげで清潔な配色にする。', filter: 'saturate(1.05) hue-rotate(18deg)' }
    ]
  },
  {
    key: 'font',
    label: '文字 の 大きさ',
    options: [
      { v: 'm',  l: '標準',        brief: '', scale: 1 },
      { v: 'l',  l: '大きめ',      brief: '文字は大きめにして読みやすさを優先する。一文は短くする。', scale: 1.14 },
      { v: 'xl', l: 'とても大きい', brief: '文字をかなり大きくし、年配の方でも読めるようにする。一文を短く、漢字と横文字を減らす。', scale: 1.3 },
      { v: 's',  l: '小さめ・洗練', brief: '文字は小さめで、余白を活かした洗練された見た目にする。', scale: 0.92 }
    ]
  },
  {
    key: 'photo',
    label: '写真 の 使い方',
    options: [
      { v: 'auto', l: 'おまかせ',        brief: '' },
      { v: 'many', l: '写真たっぷり',    brief: '写真を主役にして、文章は短く添える程度にする。' },
      { v: 'hero', l: '大きな1枚で見せる', brief: '冒頭に大きな写真を1枚置いて印象づけ、以降は落ち着いた構成にする。' },
      { v: 'few',  l: '写真少なめ・文字中心', brief: '写真は控えめにして、文章で伝える構成にする。' }
    ]
  },
  {
    key: 'age',
    label: 'お客さん の 年齢層',
    options: [
      { v: 'auto',   l: 'おまかせ',   brief: '' },
      { v: '10_20',  l: '10〜20代',   brief: '10〜20代に向けて、テンポの良いくだけた言葉づかいにする。' },
      { v: '30_40',  l: '30〜40代',   brief: '30〜40代に向けて、実利が伝わる落ち着いた言葉づかいにする。' },
      { v: '50_60',  l: '50〜60代',   brief: '50〜60代に向けて、丁寧で安心感のある言葉づかいにする。' },
      { v: '70',     l: '70代以上',   brief: '70代以上に向けて、やさしい言葉で、専門用語と横文字を避ける。' },
      { v: 'family', l: 'ファミリー', brief: '家族連れに向けて、子ども連れでも安心できる点が伝わる書き方にする。' }
    ]
  },
  {
    key: 'amount',
    label: '情報量',
    options: [
      { v: 'std',    l: '標準',        brief: '' },
      { v: 'simple', l: 'シンプル',    brief: '情報を絞り、見出しと要点だけで完結させる。' },
      { v: 'rich',   l: 'しっかり説明', brief: 'サービス内容や来店の流れをしっかり説明し、疑問が残らないようにする。' }
    ]
  },
  {
    key: 'cta',
    label: 'いちばん して ほしい 行動',
    options: [
      { v: 'auto',    l: 'おまかせ',        brief: '' },
      { v: 'tel',     l: '電話してほしい',   brief: '電話での問い合わせを一番目立たせる。' },
      { v: 'reserve', l: '予約してほしい',   brief: '予約への導線を一番目立たせる。' },
      { v: 'line',    l: 'LINE 登録してほしい', brief: 'LINE の友だち追加を一番目立たせる。' },
      { v: 'visit',   l: '来店してほしい',   brief: '場所・行き方・駐車場など、来店に必要な情報を目立たせる。' }
    ]
  }
];

// 何も 選ば れて いない 時 の 土台 (これ 単体 でも 20 文字 以上 = AI 生成 が 通る)
const ML_DESIGN_BASE =
  'その店にしかない具体を書き、「地域で愛される」「お客様の笑顔」のような業界のテンプレ表現は使わない。' +
  '客が迷わず電話・予約までたどり着ける情報設計を優先する。';

function mlDesignDefaults() {
  const d = {};
  ML_DESIGN_GROUPS.forEach((g) => { d[g.key] = g.options[0].v; });
  return d;
}

function mlDesignOption(groupKey, value) {
  const g = ML_DESIGN_GROUPS.find((x) => x.key === groupKey);
  if (!g) return null;
  return g.options.find((o) => o.v === value) || g.options[0];
}

// chips の 選択 → AI に 渡す 指示文
function mlBuildDesignBrief(sel, freeText) {
  const lines = [];
  ML_DESIGN_GROUPS.forEach((g) => {
    const o = mlDesignOption(g.key, (sel || {})[g.key]);
    if (o && o.brief) lines.push('・' + o.brief);
  });
  let out = ML_DESIGN_BASE;
  if (lines.length) out += '\n\n【この案件で指定されたデザイン方針】\n' + lines.join('\n');
  const free = (freeText || '').trim();
  if (free) out += '\n\n【補足（自由記入）】\n' + free;
  return out;
}

// chips の 選択 → preview の 見た目
function mlDesignVisual(sel) {
  const s = sel || {};
  const vibe = mlDesignOption('vibe', s.vibe);
  const color = mlDesignOption('color', s.color);
  const font = mlDesignOption('font', s.font);
  return {
    style: (vibe && vibe.style) || null,
    filter: (color && color.filter) || 'none',
    scale: (font && font.scale) || 1,
    photo: s.photo || 'auto'
  };
}

if (typeof self !== 'undefined') {
  self.ML_DESIGN_GROUPS = ML_DESIGN_GROUPS;
  self.mlDesignDefaults = mlDesignDefaults;
  self.mlDesignOption = mlDesignOption;
  self.mlBuildDesignBrief = mlBuildDesignBrief;
  self.mlDesignVisual = mlDesignVisual;
}
